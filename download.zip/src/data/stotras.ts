

import type { StaticImageData } from 'next/image';
import React from 'react';
import { cn } from '@/lib/utils';


export interface StotraVerse {
    verse: number;
    sanskrit: string;
    meaning?: string; // Optional meaning
    transliteration?: string; // Optional transliteration
}

export interface Stotra {
    id: string; // Unique identifier (e.g., "shiva-tandava")
    title: string;
    sanskritTitle?: string; // Optional title in Sanskrit
    description: string; // Brief description of the stotra
    composer?: string; // Optional composer (e.g., Adi Shankaracharya, Ravana)
    deity: string; // Primary deity praised (e.g., Shiva, Kaal Bhairava)
    verses: StotraVerse[];
    aiHint?: string; // Hint for image generation on landing page
    image?: string | StaticImageData; // Optional image for landing page
    verse_count?: string; // From new data
    theme?: string; // From new data
}

// Data for Stotras
export const stotrasData: Stotra[] = [
    {
        id: "dakshinamurthy-stotram",
        title: "Dakshinamurthy Stotram",
        sanskritTitle: "दक्षिणामूर्ति स्तोत्रम्",
        description: "A profound hymn by Adi Shankaracharya praising Lord Shiva as the cosmic teacher imparting knowledge through silence.",
        composer: "Adi Shankaracharya",
        deity: "Shiva (Dakshinamurthy)",
        verse_count: "10 verses",
        theme: "Praises Lord Shiva as the cosmic teacher imparting knowledge through silence.",
        verses: [
            {
                verse: 0.1,
                sanskrit: "मौनव्याख्या प्रकटित परब्रह्मतत्त्वं युवानं\nवर्षिष्ठांते वसद् ऋषिगणैः आवृतं ब्रह्मनिष्ठैः ।\nआचार्येन्द्रं करकलित चिन्मुद्रमानंदमूर्तिं\nस्वात्मारामं मुदितवदनं दक्षिणामूर्तिमीडे ॥१॥",
                meaning: "I praise Dakshinamurthy, the young Guru who reveals the knowledge of the supreme Brahman through silent explanation, who is surrounded by aged disciples established in Brahman, the best of teachers, whose hand holds the Chinmudra, the embodiment of bliss, who rejoices in his own Self, and whose face is joyful.",
                transliteration: "Mauna-Vyaakhyaa Prakattita Para-Brahma-Tattvam Yuvaanam\nVarssisstthaam-Te Vasad Rssigannaih Aavrtam Brahma-Nisstthaih |\nAacaarye[a-I]ndram Kara-Kalita Cin-Mudram-Aananda-Muurtim\nSva-[A]atmaaraamam Mudita-Vadanam Dakssinnaamuurti-Miidde ||1||"
            },
            {
                verse: 0.2,
                sanskrit: "वटविटपिसमीपेभूमिभागे निषण्णं\nसकलमुनिजनानां ज्ञानदातारमारात् ।\nत्रिभुवनगुरुमीशं दक्षिणामूर्तिदेवं\nजननमरणदुःखच्छेद दक्षं नमामि ॥२॥",
                meaning: "I bow to Lord Dakshinamurthy, seated on the ground near the Banyan tree, the nearby bestower of knowledge to all sages, the Guru of the three worlds, the Lord, adept at cutting away the sorrows of birth and death.",
                transliteration: "Vatta-Vittapi-Samiipe-Bhuumi-Bhaage Nissannnnam\nSakala-Muni-Janaanaam Jnyaana-Daataaram-Aaraat |\nTri-Bhuvana-Gurum-Iisham Dakssinnaamuurti-Devam\nJanana-Maranna-Duhkhac-Cheda Dakssam Namaami ||2||"
            },
            {
                verse: 0.3,
                sanskrit: "चित्रं वटतरोर्मूले वृद्धाः शिष्या गुरुर्युवा ।\nगुरोस्तु मौनं व्याख्यानं शिष्यास्तुच्छिन्नसंशयाः ॥३॥",
                meaning: "Wonderful! Under the Banyan tree, the disciples are old, the Guru is young. The Guru's explanation is silence, yet the disciples' doubts are dispelled.",
                transliteration: "Citram Vatta-Taror-Muule Vrddhaah Shissyaa Gurur-Yuvaa |\nGuros-Tu Maunam Vyaakhyaanam Shissyaas-Tuc-Chinna-Samshayaah ||3||"
            },
             {
                verse: 0.4,
                sanskrit: "निधये सर्वविद्यानां भिषजे भवरोगिणाम् ।\nगुरवे सर्वलोकानां दक्षिणामूर्तये नमः ॥४॥",
                meaning: "Salutations to Dakshinamurthy, the repository of all knowledge, the physician for those afflicted by the disease of worldly existence (samsara), the Guru of all worlds.",
                transliteration: "Nidhaye Sarva-Vidyaanaam Bhissaje Bhava-Roginnaam |\nGurave Sarva-Lokaanaam Dakssinnaamuurtaye Namah ||4||"
            },
            {
                verse: 0.5,
                sanskrit: "ॐ नमः प्रणवार्थाय शुद्धज्ञानैकमूर्तये ।\nनिर्मलाय प्रशान्ताय दक्षिणामूर्तये नमः ॥५॥",
                meaning: "Om, Salutations to Dakshinamurthy, who is the meaning of Pranava (Om), the embodiment of pure, non-dual knowledge, stainless and utterly peaceful.",
                transliteration: "Om Namah Prannava-Arthaaya Shuddha-Jnyaanai[a-E]ka-Muurtaye |\nNirmalaaya Prashaantaaya Dakssinnaamuurtaye Namah ||5||"
            },
            {
                verse: 0.6,
                sanskrit: "चिद्घनाय महेशाय वटमूलनिवासिने ।\nसच्चिदानन्दरूपाय दक्षिणामूर्तये नमः ॥६॥",
                meaning: "Salutations to Dakshinamurthy, the mass of consciousness, the Great Lord residing under the Banyan tree, whose form is Existence-Consciousness-Bliss (Satchidananda).",
                transliteration: "Cid-Ghanaaya Mahe[aa-Ii]shaaya Vatta-Muula-Nivaasine |\nSac-Cid-Aananda-Ruupaaya Dakssinnaamuurtaye Namah ||6||"
            },
            {
                verse: 0.7,
                sanskrit: "ईश्वरो गुरुरात्मेति मूर्तिभेदविभागिने ।\nव्योमवद् व्याप्तदेहाय दक्षिणामूर्तये नमः ॥७॥",
                meaning: "Salutations to Dakshinamurthy, who manifests in different forms as God, Guru, and Self, whose body pervades everything like ether (space).",
                transliteration: "Iishvaro Gurur-Aatme[a-I]ti Muurti-Bheda-Vibhaagine |\nVyoma-Vad Vyaapta-Dehaaya Dakssinnaamuurtaye Namah ||7||"
            },
            {
                verse: 1,
                sanskrit: "विश्वं दर्पणदृश्यमाननगरीतुल्यं निजान्तर्गतं\nपश्यन्नात्मनि मायया बहिरिवोद्भूतं यथा निद्रया ।\nयः साक्षात्कुरुते प्रबोधसमये स्वात्मानमेवाद्वयं\nतस्मै श्रीगुरुमूर्तये नम इदं श्रीदक्षिणामूर्तये ॥१॥",
                meaning: "He who sees the universe, which is like a city seen in a mirror, as existing within himself, yet appearing outside due to Maya, like in a dream – upon awakening, realizes his own non-dual Self. To that Sri Gurumurti, this salutation to Sri Dakshinamurthy.",
                transliteration: "Vishvam Darpanna-Drshyamaana-Nagarii-Tulyam Nija-Antargatam\nPashyann-Aatmani Maayayaa Bahir-Ivo[a-U]dbhuutam Yathaa Nidrayaa |\nYah Saakssaat-Kurute Prabodha-Samaye Sva-[A]atmaanam-Eva-Advayam\nTasmai Shrii-Guru-Muurtaye Nama Idam Shrii-Dakssinnaamuurtaye ||1||"
            },
            {
                verse: 2,
                sanskrit: "बीजस्याऽन्तरिवाङ्कुरो जगदिदं प्राङ्गनिर्विकल्पं पुनः\nमायाकल्पितदेशकालकलना वैचित्र्यचित्रीकृतम् ।\nमायावीव विजृम्भयत्यपि महायोगीव यः स्वेच्छया\nतस्मै श्रीगुरुमूर्तये नम इदं श्रीदक्षिणामूर्तये ॥२॥",
                meaning: "This universe, initially undifferentiated like the sprout within a seed, later becomes diverse, painted by the distinctions of space and time conjured by Maya. He who, like a magician or a great Yogi, unfolds this universe by His own will – To that Sri Gurumurti, this salutation to Sri Dakshinamurthy.",
                transliteration: "Biijasya-Antar-Iva-Angkuro Jagad[t]-Idam Praangga-Nirvikalpam Punah\nMaayaa-Kalpita-Desha-Kaala-Kalanaa Vaicitrya-Citrii-Krtam |\nMaayaavi-Iva Vijrmbhayaty-Api Mahaa-Yogi-Iva Yah Sve[a-I]cchayaa\nTasmai Shrii-Guru-Muurtaye Nama Idam Shrii-Dakssinnaamuurtaye ||2||"
            },
            {
                verse: 3,
                sanskrit: "यस्यैव स्फुरणं सदात्मकमसत्कल्पार्थकं भासते\nसाक्षात्तत्त्वमसीति वेदवचसा यो बोधयत्याश्रितान् ।\nयत्साक्षात्करणाद्भवेन्न पुनरावृत्तिर्भवाम्भोनिधौ\nतस्मै श्रीगुरुमूर्तये नम इदं श्रीदक्षिणामूर्तये ॥३॥",
                meaning: "He whose light alone, which is of the nature of Existence (Sat), shines forth appearing as unreal, changing objects. He who teaches his devotees directly through the Vedic statement 'Tat Tvam Asi' (That Thou Art). By realizing Him directly, one does not return to the ocean of worldly existence – To that Sri Gurumurti, this salutation to Sri Dakshinamurthy.",
                transliteration: "Yasya-Eva Sphurannam Sada[a-A]atmakam-Asat-Kalpa-Arthakam Bhaasate\nSaakssaat-Tat-Tvam-Asi-Iti Veda-Vacasaa Yo Bodhayaty-Aashritaan |\nYat-Saakssaat-Karannaad-Bhaven-Na Punaraavrttir-Bhavaam-Bho-Nidhau\nTasmai Shrii-Guru-Muurtaye Nama Idam Shrii-Dakssinnaamuurtaye ||3||"
            },
             {
                verse: 4,
                sanskrit: "नानाच्छिद्रघटोदरस्थितमहादीपप्रभा भास्वरं\nज्ञानं यस्य तु चक्षुरादिकरणद्वारा वहिः स्पन्दते ।\nजानामीति तमेव भान्तमनुभात्येतत्समस्तं जगत्\nतस्मै श्रीगुरुमूर्तये नम इदं श्रीदक्षिणामूर्तये ॥४॥",
                meaning: "He whose knowledge shines forth brilliantly like the light of a great lamp placed inside a pot with many holes, pulsating outwards through the senses like eyes. 'I know' – following Him alone who shines, this entire universe shines – To that Sri Gurumurti, this salutation to Sri Dakshinamurthy.",
                transliteration: "Naanaac-Chidra-Ghatto[a-U]dara-Sthita-Mahaa-Diipa-Prabhaa Bhaasvaram\nJnyaanam Yasya Tu Cakssur-Aadi-Karanna-Dvaaraa Vahih Spandate |\nJaanaam-Iiti Tam-Eva Bhaantam-Anubhaaty-Etat-Samastam Jagat\nTasmai Shrii-Guru-Muurtaye Nama Idam Shrii-Dakssinnaamuurtaye ||4||"
            },
            {
                verse: 5,
                sanskrit: "देहं प्राणमपीन्द्रियाण्यपि चलां बुद्धिं च शून्यं विदुः\nस्त्रीबालान्धजडोपमास्त्वहमिति भ्रान्ता भृशं वादिनः ।\nमायाशक्तिविलासकल्पितमहाव्यामोहसंहारिणे\nतस्मै श्रीगुरुमूर्तये नम इदं श्रीदक्षिणामूर्तये ॥५॥",
                meaning: "Those deluded thinkers who strongly identify 'I' with the body, breath, senses, flickering intellect, or the void – comparable to women, children, the blind, or the dull – He destroys the great delusion created by the play of Maya's power – To that Sri Gurumurti, this salutation to Sri Dakshinamurthy.",
                transliteration: "Deham Praannam-Api-Indriyaanny-Api Calaam Buddhim Ca Shuunyam Viduh\nStrii-Baala-Andha-Jaddo(a-U)pamaas-tv[u-]Aham-Iti Bhraantaa Bhrsham Vaadinah |\nMaayaa-Shakti-Vilaasa-Kalpita-Mahaa-Vyaamoha-Samhaarinne\nTasmai Shrii-Guru-Muurtaye Nama Idam Shrii-Dakssinnaamuurtaye ||5||"
            },
             {
                verse: 6,
                sanskrit: "राहुग्रस्तदिवाकरेन्दुसदृशो मायासमाच्छादनात्\nसन्मात्रः करणोपसंहरणतो योऽभूत्सुषुप्तः पुमान् ।\nप्रागस्वाप्समिति प्रबोधसमये यः प्रत्यभिज्ञायते\nतस्मै श्रीगुरुमूर्तये नम इदं श्रीदक्षिणामूर्तये ॥६॥",
                meaning: "Like the sun or moon eclipsed by Rahu, the Self (Puman), though pure Existence (Sat), becomes dormant (Sushupta) due to the covering of Maya and the withdrawal of senses. He who, upon awakening, recognizes 'Previously, I slept' – To that Sri Gurumurti, this salutation to Sri Dakshinamurthy.",
                transliteration: "Raahu-Grasta-Divaakare[a-I]ndu-Sadrsho Maayaa-Sama-[A]acchaadanaat\nSan-Maatrah Karanno[a-U]pasangharannato Yo(a-A]bhuut-Sussuptah Pumaan |\nPraag-Asvaapsam-Iti Prabodha-Samaye Yah Pratyabhijnyaayate\nTasmai Shrii-Guru-Muurtaye Nama Idam Shrii-Dakssinnaamuurtaye ||6||"
            },
             {
                verse: 7,
                sanskrit: "बाल्यादिष्वपि जाग्रदादिषु तथा सर्वास्ववस्थास्वपि\nव्यावृत्तास्वनुवर्तमानमहमित्यन्तः स्फुरन्तं सदा ।\nस्वात्मानं प्रकटीकरोति भजतां यो मुद्रयाभद्रया\nतस्मै श्रीगुरुमूर्तये नम इदं श्रीदक्षिणामूर्तये ॥७॥",
                meaning: "He who reveals His own Self – which always shines within as 'I', persisting through changing states like childhood etc., and waking etc., even as they cease – to devotees through the auspicious Chinmudra – To that Sri Gurumurti, this salutation to Sri Dakshinamurthy.",
                transliteration: "Baalya-Adissv(u)-Api Jaagrad-Aadissu Tathaa Sarvaasv[u]-Avasthaasv[u]-Api\nVyaavrttaasv[u]-Anu-Vartamaanam-Aham-Ity[i]-Antah Sphurantam Sadaa |\nSva-[A]atmaanam Prakattii-Karoti Bhajataam Yo Mudrayaa-Bhadrayaa\nTasmai Shrii-Guru-Muurtaye Nama Idam Shrii-Dakssinnaamuurtaye ||7||"
            },
            {
                verse: 8,
                sanskrit: "विश्वं पश्यति कार्यकारणतया स्वस्वामिसम्बन्धतः\nशिष्याचार्यतया तथैव पितृपुत्राद्यात्मना भेदतः ।\nस्वप्ने जाग्रति वा य एष पुरुषो मायापरिभ्रामितः\nतस्मै श्रीगुरुमूर्तये नम इदं श्रीदक्षिणामूर्तये ॥८॥",
                meaning: "This very Self (Purusha), deluded by Maya, sees the world in terms of cause-effect, owner-owned relationships, teacher-disciple, and similarly father-son etc., through differentiation, whether in dream or waking state – To that Sri Gurumurti, this salutation to Sri Dakshinamurthy.",
                transliteration: "Vishvam Pashyati Kaarya-Kaaranna-Tayaa Svasvaami-Sambandhatah\nShissya-[A]acaarya-Tayaa Tatha-Eva Pitr-Putraady[i]-Aatmanaa Bhedatah |\nSvapne Jaagrati Vaa Ya Essa Purusso Maayaa-Paribhraamitah\nTasmai Shrii-Guru-Muurtaye Nama Idam Shrii-Dakssinnaamuurtaye ||8||"
            },
            {
                verse: 9,
                sanskrit: "भूरम्भांस्यनलोऽनिलोऽम्बरमहर्नाथो हिमांशु पुमान्\nइत्याभाति चराचरात्मकमिदं यस्यैव मूर्त्यष्टकम्\nनान्यत् किञ्चन विद्यते विमृशतां यस्मात्परस्माद्विभोः\nतस्मै श्रीगुरुमूर्तये नम इदं श्रीदक्षिणामूर्तये ॥९॥",
                meaning: "Earth, water, fire, air, ether, sun, moon, and the individual soul (Puman) – this universe of moving and unmoving things shines forth as His eightfold form. For those who reflect, nothing exists other than Him, the Supreme Lord (Vibhu) – To that Sri Gurumurti, this salutation to Sri Dakshinamurthy.",
                transliteration: "Bhuur-Ambhaamsy-Analo-[A]nilo-[A]mbaram-Aharnaatho Himaamshu Pumaan\nIty[i]-Aabhaati Cara-Acara-[A]atmakam-Idam Yasya-Eva Muurty[i]-Assttakam\nNaanyat Kin.cana Vidyate Vimrshataam Yasmaat-Parasmaad-Vibhoh\nTasmai Shrii-Guru-Muurtaye Nama Idam Shrii-Dakssinnaamuurtaye ||9||"
            },
            {
                verse: 10,
                sanskrit: "सर्वात्मत्वमिति स्फुटीकृतमिदं यस्मादमुष्मिन् स्तवे\nतेनास्य श्रवणात्तदर्थमननाद्ध्यानाच्च संकीर्तनात् ।\nसर्वात्मत्वमहाविभूतिसहितं स्यादीश्वरत्वं स्वतः\nसिद्ध्येत्तत्पुनरष्टधा परिणतं चैश्वर्यमव्याहतम् ॥१०॥",
                meaning: "Because the state of being the Self of all (Sarvatmatva) is clearly revealed in this hymn, by listening to it, reflecting on its meaning, meditating upon it, and chanting it, one spontaneously attains Lordship (Ishvaratva) along with the great glory of being the Self of all, and furthermore, the eightfold unimpeded powers (Aishwarya) will be accomplished.",
                transliteration: "Sarva-[A]atmatvam-Iti Sphuttii-Krtam-Idam Yasmaad-Amussmin Stave\nTena-Asya Shravannaat-Tadartha-Mananaad-Dhyaanaac-Ca Sangkiirtanaat |\nSarva-(A)atmatva-Mahaa-Vibhuuti-Sahitam Syaad-Iishvaratvam Svatah\nSiddhyet-Tat-Punar-Assttadhaa Parinnatam Ca-[A]ishvaryam-Avyaahatam ||10||"
            },
        ],
        aiHint: "shiva dakshinamurthy teacher guru silence wisdom adi shankaracharya",
        image: `https://picsum.photos/seed/dakshinamurthy/400/225`
    },
    {
        id: "kaal-bhairava-ashtakam",
        title: "Kaal Bhairava Ashtakam",
        sanskritTitle: "कालभैरवाष्टकम्",
        description: "Devotional praise to Kaal Bhairava, guardian of Kashi, destroyer of fear.",
        composer: "Adi Shankaracharya",
        deity: "Kaal Bhairava (Shiva)",
        verse_count: "8 verses",
        theme: "Devotional praise to Kaal Bhairava, guardian of Kashi, destroyer of fear.",
        verses: [
             {
                verse: 1,
                sanskrit: "देवराजसेव्यमानपावनाङ्घ्रिपङ्कजं\nव्यालयज्ञसूत्रमिन्दुशेखरं कृपाकरम् ।\nनारदादियोगिवृन्दवन्दितं दिगंबरं\nकाशिकापुराधिनाथ कालभैरवं भजे ॥१॥",
                meaning: "I worship Kaal Bhairava, the supreme Lord of Kashi, whose lotus feet are revered by Indra (King of Devas), who wears a serpent as his sacred thread, has the moon on his forehead, is the bestower of mercy, is praised by Narada and other yogis, and is Digambara (clad in directions/naked)."
            },
            {
                verse: 2,
                sanskrit: "भानुकोटिभास्वरं भवाब्धितारकं परं\nनीलकण्ठमीप्सितार्थदायकं त्रिलोचनम् ।\nकालकालमंबुजाक्षमक्षशूलमक्षरं\nकाशिकापुराधिनाथ कालभैरवं भजे ॥२॥",
                meaning: "I worship Kaal Bhairava, the supreme Lord of Kashi, who shines like millions of suns, helps cross the ocean of existence, is supreme, has a blue throat, grants desired boons, has three eyes, is the death of death (Kala), has lotus-like eyes, holds an invincible trident (or spear), and is imperishable."
            },
            {
                verse: 3,
                sanskrit: "शूलटङ्कपाशदण्डपाणिमादिकारणं\nश्यामकायमादिदेवमक्षरं निरामयम् ।\nभीमविक्रमं प्रभुं विचित्रताण्डवप्रियं\nकाशिकापुराधिनाथ कालभैरवं भजे ॥३॥",
                meaning: "I worship Kaal Bhairava, the supreme Lord of Kashi, who holds a trident, axe, noose, and staff; the primeval cause, dark-bodied, the first god, imperishable, free from disease, possesses formidable prowess, the Lord who loves the wondrous Tandava dance."
            },
            {
                verse: 4,
                sanskrit: "भुक्तिमुक्तिदायकं प्रशस्तचारुविग्रहं\nभक्तवत्सलं स्थितं समस्तलोकविग्रहम् ।\nविनिक्वणन्मनोज्ञहेमकिङ्किणीलसत्कटिं\nकाशिकापुराधिनाथ कालभैरवं भजे ॥४॥",
                meaning: "I worship Kaal Bhairava, the supreme Lord of Kashi, the bestower of worldly enjoyment and liberation, having a praiseworthy beautiful form, affectionate towards devotees, abiding as the form of all worlds, whose waist adorned with tiny golden bells tinkles melodiously."
            },
            {
                verse: 5,
                sanskrit: "धर्मसेतुपालकं त्वधर्ममार्गनाशकं\nकर्मपाशमोचकं सुशर्मदायकं विभुम् ।\nस्वर्णवर्णशेषपाशशोभिताङ्गमण्डलं\nकाशिकापुराधिनाथ कालभैरवं भजे ॥५॥",
                meaning: "I worship Kaal Bhairava, the supreme Lord of Kashi, the protector of the bridge of Dharma, the destroyer of the path of Adharma, the liberator from the bonds of Karma, the bestower of good fortune, the omnipresent Lord, whose body is adorned with a golden-hued serpent-noose."
            },
            {
                verse: 6,
                sanskrit: "रत्नपादुकाप्रभाभिरामपादयुग्मकं\nनित्यमद्वितीयमिष्टदैवतं निरञ्जनम् ।\nमृत्युदर्पनाशनं करालदंष्ट्रमोक्षणं\nकाशिकापुराधिनाथ कालभैरवं भजे ॥६॥",
                meaning: "I worship Kaal Bhairava, the supreme Lord of Kashi, whose pair of feet are radiant with gem-studded sandals, who is eternal, without a second, the desired deity, stainless, the destroyer of the pride of Death, and who grants liberation through his fearsome fangs."
            },
            {
                verse: 7,
                sanskrit: "अट्टहासभिन्नपद्मजाण्डकोशसन्ततिं\nदृष्टिपातनष्टपापजालमुग्रशासनम् ।\nअष्टसिद्धिदायकं कपालमालिकाधरं\nकाशिकापुराधिनाथ कालभैरवं भजे ॥७॥",
                meaning: "I worship Kaal Bhairava, the supreme Lord of Kashi, whose loud laughter shatters the multitude of universes born from Brahma, whose mere glance destroys the web of sins, who enforces stern discipline, the bestower of the eight siddhis (accomplishments), wearing a garland of skulls."
            },
            {
                verse: 8,
                sanskrit: "भूतसङ्घनायकं विशालकीर्तिदायकं\nकाशिवासलोकपुण्यपापशोधकं विभुम् ।\nनीतिमार्गकोविदं पुरातनं जगत्पतिं\nकाशिकापुराधिनाथ कालभैरवं भजे ॥८॥",
                meaning: "I worship Kaal Bhairava, the supreme Lord of Kashi, the leader of the ghost hordes, the bestower of vast fame, the purifier of the merits and sins of the people residing in Kashi, the omnipresent Lord, proficient in the path of righteousness, ancient, the lord of the universe."
            },
            {
                verse: 9,
                sanskrit: "कालभैरवाष्टकं पठन्ति ये मनोहरं\nज्ञानमुक्तिसाधनं विचित्रपुण्यवर्धनम् ।\nशोकमोहदैन्यलोभकोपतापनाशनं\nते प्रयान्ति कालभैरवाङ्घ्रिसन्निधिं ध्रुवम् ॥९॥",
                meaning: "Those who read this captivating Kaal Bhairava Ashtakam, which is a means to attain knowledge and liberation, increases diverse merits, and destroys sorrow, delusion, poverty, greed, anger, and suffering, will certainly attain the proximity of Kaal Bhairava's feet after death."
            },
        ],
        aiHint: "kaal bhairava shiva kashi adi shankaracharya fierce",
        image: `https://picsum.photos/seed/kaal-bhairava-stotra/400/225`
    },
    {
        id: "lingashtakam",
        title: "Lingashtakam",
        sanskritTitle: "लिङ्गाष्टकम्",
        description: "Extols the virtues and spiritual significance of the Shiva Lingam.",
        composer: "Traditionally attributed to Adi Shankaracharya",
        deity: "Shiva (Lingam)",
        verse_count: "8 verses",
        theme: "Extols the virtues and spiritual significance of the Shiva Lingam.",
        verses: [
            {
                verse: 1,
                sanskrit: "ब्रह्ममुरारिसुरार्चितलिङ्गं निर्मलभासितशोभितलिङ्गम् ।\nजन्मजदुःखविनाशकलिङ्गं तत् प्रणमामि सदाशिवलिङ्गम् ॥१॥",
                meaning: "I bow before that Sadaashiva Lingam, which is adored by Brahma, Vishnu and other Gods, which is pure, radiant, and resplendent, and which destroys the sorrows associated with birth.",
                transliteration: "Brahma-Muraari-Sura-Arcita-Linggam Nirmala-Bhaasita-Shobhita-Linggam |\nJanmaja-Duhkha-Vinaashaka-Linggam Tat Prannamaami Sadaashiva-Linggam ||1||"
            },
            {
                verse: 2,
                sanskrit: "देवमुनिप्रवरार्चितलिङ्गं कामदहं करुणाकरलिङ्गम् ।\nरावणदर्पविनाशनलिङ्गं तत् प्रणमामि सदाशिवलिङ्गम् ॥२॥",
                meaning: "I bow before that Sadaashiva Lingam, which is worshipped by the foremost Devas and Sages, which burns Kama (desire), the compassionate Lingam, and which destroyed the arrogance of Ravana.",
                transliteration: "Deva-Muni-Pravara-Aarcita-Linggam Kaama-Dahan Karunnaa-Kara-Linggam |\nRaavanna-Darpa-Vinaashana-Linggam Tat Prannamaami Sadaashiva-Linggam ||2||"
            },
            {
                verse: 3,
                sanskrit: "सर्वसुगन्धिसुलेपितलिङ्गं बुद्धिविवर्धनकारणलिङ्गम् ।\nसिद्धसुरासुरवन्दितलिङ्गं तत् प्रणमामि सदाशिवलिङ्गम् ॥३॥",
                meaning: "I bow before that Sadaashiva Lingam, which is anointed with all fragrant scents, which is the cause for the growth of wisdom, and which is worshipped by Siddhas, Devas, and Asuras.",
                transliteration: "Sarva-Sugandhi-Sulepita-Linggam Buddhi-Vivardhana-Kaaranna-Linggam |\nSiddha-Sura-Asura-Vandita-Linggam Tat Prannamaami Sadaashiva-Linggam ||3||"
            },
            {
                verse: 4,
                sanskrit: "कनकमहामणिभूषितलिङ्गं फणिपतिवेष्टितशोभितलिङ्गम् ।\nदक्षसुयज्ञविनाशनलिङ्गं तत् प्रणमामि सदाशिवलिङ्गम् ॥४॥",
                meaning: "I bow before that Sadaashiva Lingam, adorned with gold and great jewels, resplendent, encircled by the lord of serpents (Phanipati), and which destroyed the grand sacrifice of Daksha.",
                transliteration: "Kanaka-Mahaamanni-Bhuussita-Linggam Phanni-Pati-Vessttita-Shobhita-Linggam |\nDakssa-Su-Yajnya-Vinaashana-Linggam Tat Prannamaami Sadaashiva-Linggam ||4||"
            },
            {
                verse: 5,
                sanskrit: "कुङ्कुमचन्दनलेपितलिङ्गं पङ्कजहारसुशोभितलिङ्गम् ।\nसञ्चितपापविनाशनलिङ्गं तत् प्रणमामि सदाशिवलिङ्गम् ॥५॥",
                meaning: "I bow before that Sadaashiva Lingam, smeared with Kumkum (vermillion) and Sandalwood paste, beautifully adorned with lotus garlands, and which destroys accumulated sins.",
                transliteration: "Kungkuma-Candana-Lepita-Linggam Pangkaja-Haara-Su-Shobhita-Linggam |\nSan.cita-Paapa-Vinaashana-Linggam Tat Prannamaami Sadaashiva-Linggam ||5||"
            },
            {
                verse: 6,
                sanskrit: "देवगणार्चितसेवितलिङ्गं भावैर्भक्तिभिरेव च लिङ्गम् ।\nदिनकरकोटिप्रभाकरलिङ्गं तत् प्रणमामि सदाशिवलिङ्गम् ॥६॥",
                meaning: "I bow before that Sadaashiva Lingam, worshipped and served by the hosts of Devas with true devotional feelings (Bhavas) and devotion (Bhakti), and whose splendor is like millions of suns.",
                transliteration: "Deva-Ganna-Aarcita-Sevita-Linggam Bhaavair-Bhaktibhir-Eva Ca Linggam |\nDinakara-Kotti-Prabhaakara-Linggam Tat Prannamaami Sadaashiva-Linggam ||6||"
            },
            {
                verse: 7,
                sanskrit: "अष्टदलोपरिवेष्टितलिङ्गं सर्वसमुद्भवकारणलिङ्गम् ।\nअष्टदरिद्रविनाशितलिङ्गं तत् प्रणमामि सदाशिवलिङ्गम् ॥७॥",
                meaning: "I bow before that Sadaashiva Lingam, surrounded by eight-petaled lotuses, the cause of all creation, and the destroyer of the eight forms of poverty.",
                transliteration: "Asstta-Dalo-Parivessttita-Linggam Sarva-Samudbhava-Kaaranna-Linggam |\nAsstta-Daridra-Vinaashita-Linggam Tat Prannamaami Sadaashiva-Linggam ||7||"
            },
            {
                verse: 8,
                sanskrit: "सुरगुरुसुरवरपूजितलिङ्गं सुरवनपुष्पसदार्चितलिङ्गम् ।\nपरात्परं परमात्मकलिङ्गं तत् प्रणमामि सदाशिवलिङ्गम् ॥८॥",
                meaning: "I bow before that Sadaashiva Lingam, worshipped by the Guru of Devas (Brihaspati) and the best of Devas, constantly worshipped with flowers from celestial gardens (Suravana), the Lingam which is the Supreme Being, beyond the beyond.",
                transliteration: "Suraguru-Suravara-Puujita-Linggam Suravana-Pusspa-Sada-Aarcita-Linggam |\nParaatparam Paramaatmaka-Linggam Tat Prannamaami Sadaashiva-Linggam ||8||"
            },
            {
                verse: 9,
                sanskrit: "लिङ्गाष्टकमिदं पुण्यं यः पठेत् शिवसन्निधौ ।\nशिवलोकमवाप्नोति शिवेन सह मोदते ॥",
                meaning: "Whoever reads this sacred Lingashtakam in the presence of Shiva, attains the abode of Shiva (Shivaloka) and rejoices with Shiva.",
                transliteration: "Linggaassttakam-Idam Punnyam Yah Patthet Shiva-Sannidhau |\nShiva-Lokam-Avaapnoti Shivena Saha Modate ||"
            }
        ],
        aiHint: "shiva lingam worship eight verses adi shankaracharya",
        image: `https://picsum.photos/seed/lingashtakam/400/225`
    },
    {
        id: "rudrashtakam",
        title: "Rudrashtakam",
        sanskritTitle: "रुद्राष्टकम्",
        description: "Praises Lord Rudra’s divine qualities and seeks his grace.",
        composer: "Goswami Tulsidas",
        deity: "Rudra (Shiva)",
        verse_count: "8 verses",
        theme: "Praises Lord Rudra’s divine qualities and seeks his grace.",
        verses: [
            {
                verse: 1,
                sanskrit: "नमामीशमीशान निर्वाणरूपं\nविभुं व्यापकं ब्रह्मवेदस्वरूपम् ।\nनिजं निर्गुणं निर्विकल्पं निरीहं\nचिदाकाशमाकाशवासं भजेऽहम् ॥१॥",
                meaning: "I bow to the Lord Ishana, whose form is Liberation itself (Nirvana), the omnipresent and all-pervading Brahman, manifest as the Vedas. I worship Shankara, who is my own Self, devoid of attributes, indivisible, desireless, the conscious ether, residing in the sky (or heart)."
            },
            {
                verse: 2,
                sanskrit: "निराकारमोंकारमूलं तुरीयं\nगिरा ग्यान गोतीतमीशं गिरीशम् ।\nकरालं महाकाल कालं कृपालं\nगुणागार संसारपारं नतोऽहम् ॥२॥",
                meaning: "I bow to the formless One, the root of Omkara, beyond the three states (Turiya). The Lord Girisha (Lord of Mountains), who is beyond speech, knowledge, and senses. The terrifying One, the Time of Mahakala (Great Time), the compassionate One, the abode of qualities, who helps cross the ocean of Samsara (worldly existence)."
            },
            {
                verse: 3,
                sanskrit: "तुषाराद्रि संकाश गौरं गभीरं\nमनोभूत कोटिप्रभा श्री शरीरम् ।\nस्फुरन्मौलि कल्लोलिनी चारु गङ्गा\nलसद्भालबालेन्दु कण्ठे भुजङ्गा ॥३॥",
                meaning: "He is white like the snow-clad mountain (Himalayas), profound. His body possesses the splendor of millions of Kamadevas (God of Love). The beautiful Ganga river flows playfully from His radiant head. The crescent moon adorns His forehead, and serpents grace His neck."
            },
            {
                verse: 4,
                sanskrit: "चलत्कुण्डलं भ्रू सुनेत्रं विशालं\nप्रसन्नाननं नीलकण्ठं दयालम् ।\nMṛgādhīśacarmāmbaraṁ muṇḍamālaṁ\npriyaṁ śaṅkaraṁ sarvanāthaṁ bhajāmi ॥4॥",
                meaning: "With dangling earrings, beautiful eyebrows and large eyes, a cheerful face, a blue throat, the compassionate One. Wearing the skin of the lion king (or elephant hide), adorned with a garland of skulls, I worship Shankara, the beloved Lord of All."
            },
             {
                verse: 5,
                sanskrit: "प्रचण्डं प्रकृष्टं प्रगल्भं परेशं\nअखण्डं अजं भानुकोटिप्रकाशम् ।\nत्रयः शूल निर्मूलनं शूलपाणिं\nभजेऽहं भवानीपतिं भावगम्यम् ॥५॥",
                meaning: "The fierce, excellent, bold, Supreme Lord. Indivisible, unborn, radiant like millions of suns. Holding a trident, He eradicates the three types of suffering. I worship Bhavani's consort (Shiva), who is attainable through loving devotion."
            },
            {
                verse: 6,
                sanskrit: "कलातीत कल्याण कल्पान्तकारी\nपदा सज्जनानन्ददाता पुरारी ।\nचिदानन्द संदोह मोहापहारी\nप्रसीद प्रसीद प्रभो मन्मथारी ॥६॥",
                meaning: "Beyond arts, auspicious, the cause of dissolution at the end of Kalpas (eons). Always the bestower of joy to the virtuous, the enemy of Tripura. The mass of consciousness and bliss, the remover of delusion. Be pleased, be pleased, O Lord, enemy of Manmatha (God of Love)!"
            },
            {
                verse: 7,
                sanskrit: "न यावद् उमानाथ पादारविन्दं\nभजन्तीह लोके परे वा नराणाम् ।\nन तावत्सुखं शान्ति सन्तापनाशं\nप्रसीद प्रभो सर्वभूताधिवासम् ॥७॥",
                meaning: "As long as people in this world or the next do not worship the lotus feet of Umanath (Shiva), they cannot attain happiness, peace, or relief from suffering. Be pleased, O Lord, who resides in all beings!"
            },
            {
                verse: 8,
                sanskrit: "न जानामि योगं जपं नैव पूजां\nनतोऽहं सदा सर्वदा शम्भु तुभ्यम् ।\nजरा जन्म दुःखौघ तातप्यमानं\nप्रभो पाहि आपन्नमामीश शम्भो ॥८॥",
                meaning: "I do not know yoga, japa (chanting), or puja (worship). I always bow to you, Shambhu, forever! Protect me, O Lord, who am afflicted by the torrent of suffering, old age, and birth. Save the distressed, O Lord Shambhu!"
            },
            {
                 verse: 9,
                 sanskrit: "रुद्राष्टकमिदं प्रोक्तं विप्रेण हरतोषये\nये पठन्ति नरा भक्त्या तेषां शम्भुः प्रसीदति ॥९॥",
                 meaning: "This Rudrashtakam was uttered by the Vipra (Brahmin - Tulsidas) for the pleasure of Hara (Shiva). Those people who read it with devotion, Shambhu becomes pleased with them."
            },
        ],
        aiHint: "shiva rudra tulsidas hymn peace devotion",
        image: `https://picsum.photos/seed/rudrashtakam/400/225`
    },
    {
        id: "shiva-manasa-puja",
        title: "Shiva Manasa Puja",
        sanskritTitle: "शिवमानसपूजा",
        description: "Meditative mental worship of Shiva offering symbolic mental offerings.",
        composer: "Adi Shankaracharya",
        deity: "Shiva",
        verse_count: "5 verses",
        theme: "Meditative mental worship of Shiva offering symbolic mental offerings.",
        verses: [
            {
                verse: 1,
                sanskrit: "रत्नैः कल्पितमासनं हिमजलैः स्नानं च दिव्याम्बरं\nनानारत्नविभूषितं मृगमदामोदाङ्कितं चन्दनम् ।\nजातीचम्पकबिल्वपत्ररचितं पुष्पं च धूपं तथा\nदीपं देव दयानिधे पशुपते हृत्कल्पितं गृह्यताम् ॥१॥",
                meaning: "O Lord, Ocean of Mercy, Pashupati! Please accept this mentally conceived offering: a seat made of gems, a bath with cool waters, divine robes adorned with various jewels, sandalwood paste mixed with fragrant musk, flowers composed of Jati, Champaka, and Bilva leaves, incense, and a lamp.",
                transliteration: "Ratnaih Kalpitam-Aasanam Hima-Jalaih Snaanam Ca Divya-Ambaram\nNaanaa-Ratna-Vibhuussitam Mrga-Madaa-Moda-Angkitam Candanam |\nJaatii-Campaka-Bilva-Patra-Racitam Pusspam Ca Dhuupam Tathaa\nDiipam Deva Dayaa-Nidhe Pashupate Hrt-Kalpitam Grhyataam ||1||"
            },
            {
                verse: 2,
                sanskrit: "सौवर्णे नवरत्नखण्डरचिते पात्रे घृतं पायसं\nभक्ष्यं पञ्चविधं पयोदधियुतं रम्भाफलं पानकम् ।\nशाकानामयुतं जलं रुचिकरं कर्पूरखण्डोज्ज्वलं\nताम्बूलं मनसा मया विरचितं भक्त्या प्रभो स्वीकुरु ॥२॥",
                meaning: "O Lord! Please accept with devotion these offerings mentally prepared by me: Ghee and Payasam (sweet rice pudding) in a golden bowl inlaid with nine types of gems, five kinds of food items mixed with milk and curd, bananas, sweet drinks, countless vegetable dishes, tasty water brightened with camphor pieces, and betel leaves.",
                transliteration: "Sauvarnne Nava-Ratna-Khanndda-Racite Paatre Ghrtam Paayasam\nBhakssyam Pan.ca-Vidham Payo-Dadhi-Yutam Rambhaa-Phalam Paanakam |\nShaakaanaam-Ayutam Jalam Rucikaram Karpuura-Khannddo[a-U]jjvalam\nTaambuulam Manasaa Mayaa Viracitam Bhaktyaa Prabho Sviikuru ||2||"
            },
            {
                verse: 3,
                sanskrit: "छत्रं चामरयोर्युगं व्यजनकं चादर्शकं निर्मलं\nवीणाभेरिमृदङ्गकाहलकला गीतं च नृत्यं तथा ।\nसाष्टाङ्गं प्रणतिः स्तुतिर्बहुविधा ह्येतत्समस्तं मया\nसङ्कल्पेन समर्पितं तव विभो पूजां गृहाण प्रभो ॥३॥",
                meaning: "O Lord! Please accept this worship: an umbrella, a pair of Chamaras (fly-whisks), a fan, a spotless mirror, the arts of Veena, Bheri drum, Mridanga drum, Kahala horn, song and dance, full prostration (Sashtanga Pranam), various hymns – all this I have offered to You through mental conception.",
                transliteration: "Chatram Caamarayor-Yugam Vyajanakam Ca-Adarshakam Nirmalam\nViinnaa-Bheri-Mrdangga-Kaahala-Kalaa Giitam Ca Nrtyam Tathaa |\nSaassttaanggam Prannatih Stutir-Bahu-Vidhaa Hye[i-E]tat-Samastam Mayaa\nSangkalpena Samarpitam Tava Vibho Puujaam Grhaanna Prabho ||3||"
            },
            {
                verse: 4,
                sanskrit: "आत्मा त्वं गिरिजा मतिः सहचराः प्राणाः शरीरं गृहं\nपूजा ते विषयोपभोगरचना निद्रा समाधिस्थितिः ।\nசஞ்சாரః పదయోః ప్రదక్షిణవిధిః స్తోత్రాణి సర్వా గిరో\nయద్యత్కర్మ కరోమి తత్తదఖిలం शम्भो तवाराधनम् ॥४॥",
                meaning: "O Shambho! You are my Self, Girija (Parvati) is my intellect, Your attendants are my vital breaths (Pranas), my body is Your home. My worship of You is the experience of sense objects, my sleep is the state of Samadhi. My walking is the ritual of circumambulation around You, all my speech are hymns to You. Whatever actions I perform, all that is Your worship.",
                transliteration: "Aatmaa Tvam Girijaa Matih Sahacaraah Praannaah Shariiram Grham\nPuujaa Te Vissayo[a-U]pabhoga-Racanaa Nidraa Samaadhi-Sthitih |\nSan.caarah Padayoh Pradakssinna-Vidhih Stotraanni Sarvaa Giro\nYad-Yat-Karma Karomi Tat-Tad-Akhilam Shambho Tava-Araadhanam ||4||"
            },
            {
                verse: 5,
                sanskrit: "करचरणकृतं वाक्कायजं कर्मजं वा\nश्रवणनयनजं वा मानसं वापराधम् ।\nविहितमविहितं वा सर्वमेतत्क्षमस्व\nजय जय करुणाब्धे श्रीमहादेव शम्भो ॥५॥",
                meaning: "O Great God Shambho, ocean of mercy! Please forgive all my wrongdoings, whether committed by hands or feet, speech or body, actions, ears or eyes, or by the mind; whether prescribed (lawful) or not prescribed (unlawful). Victory, Victory unto Thee!",
                transliteration: "Kara-Caranna-Krtam Vaak-Kaaya-Jam Karma-Jam Vaa\nShravanna-Nayana-Jam Vaa Maanasam Va-Aparaadham |\nVihitam-Avihitam Vaa Sarvam-Etat-Kssamasva\nJaya Jaya Karunna-Abdhe Shrii-Mahaadeva Shambho ||5||"
            }
        ],
        aiHint: "shiva mental worship manasa puja adi shankaracharya devotion mind",
        image: `https://picsum.photos/seed/manasa-puja/400/225`
    },
    {
        id: "shiva-panchakshara-stotram",
        title: "Shiva Panchakshara Stotram",
        sanskritTitle: "शिव पञ्चाक्षर स्तोत्रम्",
        description: "Glorifies Shiva through the five sacred syllables Na-Ma-Shi-Va-Ya.",
        composer: "Adi Shankaracharya",
        deity: "Shiva",
        verse_count: "5 verses",
        theme: "Glorifies Shiva through the five sacred syllables Na-Ma-Shi-Va-Ya.",
        verses: [
            {
                verse: 1,
                sanskrit: "नागेन्द्रहाराय त्रिलोचनाय\nभस्माङ्गरागाय महेश्वराय ।\nनित्याय शुद्धाय दिगम्बराय\nतस्मै न काराय नमः शिवाय ॥१॥",
                meaning: "Salutations to Shiva, who wears the king of snakes as a garland, the Three-Eyed God, whose body is smeared with sacred ash, the Great Lord (Maheshvara), the eternal, the pure, the Digambara (clad in directions) - to that 'Na' syllable, Salutations to Shiva!"
            },
            {
                verse: 2,
                sanskrit: "मन्दाकिनीसलिलचन्दनचर्चिताय\nनन्दीश्वरप्रमथनाथमहेश्वराय ।\nमन्दारपुष्पबहुपुष्पसुपूजिताय\nतस्मै म काराय नमः शिवाय ॥२॥",
                meaning: "Salutations to Shiva, who is worshipped with water from the Mandakini river and sandalwood paste, the Lord of Nandi and the Pramatha ganas, the Great Lord, worshipped with Mandara and many other flowers - to that 'Ma' syllable, Salutations to Shiva!"
            },
            {
                verse: 3,
                sanskrit: "शिवाय गौरीवदनाब्जवृन्द\nसूर्याय दक्षाध्वरनाशकाय ।\nश्रीनीलकण्ठाय वृषध्वजाय\nतस्मै शि काराय नमः शिवाय ॥३॥",
                meaning: "Salutations to Shiva, who is auspiciousness itself, the sun that makes Gauri's (Parvati's) lotus-face bloom, the destroyer of Daksha's sacrifice, the one with the auspicious blue throat, whose flag bears the emblem of the bull - to that 'Shi' syllable, Salutations to Shiva!"
            },
            {
                verse: 4,
                sanskrit: "वसिष्ठकुम्भोद्भवगौतमार्य\nमूनीन्द्रदेवार्चितशेखराय ।\nचन्द्रार्कवैश्वानरलोचनाय\nतस्मै व काराय नमः शिवाय ॥४॥",
                meaning: "Salutations to Shiva, whose crest is worshipped by the best of sages like Vasishtha, Agastya (Kumbhodbhava), and Gautama, and also by the gods, and whose eyes are the moon, sun, and fire - to that 'Va' syllable, Salutations to Shiva!"
            },
            {
                verse: 5,
                sanskrit: "यक्षस्वरूपाय जटाधराय\nपिनाकहस्ताय सनातनाय ।\nदिव्याय देवाय दिगम्बराय\nतस्मै य काराय नमः शिवाय ॥५॥",
                meaning: "Salutations to Shiva, who has the form of a Yaksha, who bears matted locks, who holds the Pinaka bow in his hand, the eternal one, the divine God, the Digambara - to that 'Ya' syllable, Salutations to Shiva!"
            },
            {
                verse: 6,
                sanskrit: "पञ्चाक्षरमिदं पुण्यं यः पठेच्छिवसन्निधौ ।\nशिवलोकमावाप्नोति शिवेन सह मोदते ॥६॥",
                meaning: "Whoever reads this sacred five-syllable hymn in the presence of Shiva, attains the abode of Shiva (Shivaloka) and rejoices with Shiva."
            },
        ],
        aiHint: "shiva panchakshara mantra adi shankaracharya five syllables nagendra",
        image: `https://picsum.photos/seed/panchakshara/400/225`
    },
    {
        id: "shiva-shadakshara-stotram",
        title: "Shiva Shadakshara Stotram",
        sanskritTitle: "शिव षडक्षर स्तोत्रम्",
        description: "Meditation on Shiva through the six-syllable mantra Om Namah Shivaya.",
        composer: "Attributed to Adi Shankaracharya or Puranas",
        deity: "Shiva",
        verse_count: "6 verses",
        theme: "Meditation on Shiva through the six-syllable mantra Om Namah Shivaya.",
        verses: [
            {
                verse: 1,
                sanskrit: "ॐ कारं बिंदुसंयुक्तं नित्यं ध्यायन्ति योगिनः ।\nकामदं मोक्षदं चैव ॐ काराय नमो नमः ॥१॥",
                meaning: "Yogis constantly meditate on 'Omkara' associated with the Bindu (point/source). It grants desires and liberation. Salutations again and again to that 'Omkara'!"
            },
            {
                verse: 2,
                sanskrit: "नमंति ऋषयो देवा नमन्त्यप्सरसां गणाः ।\nनरा नमंति देवेशं न काराय नमो नमः ॥२॥",
                meaning: "Sages and Devas bow down, groups of Apsaras bow down, humans bow down to the Lord of Gods (Devesha). Salutations again and again to that 'Na' syllable!"
            },
            {
                verse: 3,
                sanskrit: "महादेवं महात्मानं महाध्यानपरायणम् ।\nमहापापहरं देवं म काराय नमो नमः ॥३॥",
                meaning: "The Great God (Mahadeva), the great soul (Mahatma), deeply absorbed in meditation (Mahadhyana), the God who destroys great sins. Salutations again and again to that 'Ma' syllable!"
            },
            {
                verse: 4,
                sanskrit: "शिवं शान्तं जगन्नाथं लोकानुग्रहकारकम् ।\nशिवमेकपदं नित्यं शि काराय नमो नमः ॥४॥",
                meaning: "Shiva, the peaceful, the Lord of the Universe (Jagannatha), who bestows grace upon the worlds. Shiva is the one eternal word/state. Salutations again and again to that 'Shi' syllable!"
            },
            {
                verse: 5,
                sanskrit: "वाहनं वृषभो यस्य वासुकिः कण्ठभूषणम् ।\nवामे शक्तिधरं देवं व काराय नमो नमः ॥५॥",
                meaning: "He whose vehicle (vahana) is the bull (Vrishabha), whose neck ornament is Vasuki (the serpent king). The God who holds Shakti (power/Parvati) on his left side. Salutations again and again to that 'Va' syllable!"
            },
            {
                verse: 6,
                sanskrit: "यत्र यत्र स्थितो देवः सर्वव्यापी महेश्वरः ।\nयो गुरुः सर्वदेवानां य काराय नमो नमः ॥६॥",
                meaning: "Wherever the God is situated, the all-pervading Great Lord (Maheshvara). He who is the Guru of all Gods. Salutations again and again to that 'Ya' syllable!"
            },
            {
                verse: 7,
                sanskrit: "षडक्षरमिदं स्तोत्रं यः पठेच्छिवसन्निधौ ।\nशिवलोकमवाप्नोति शिवेन सह मोदते ॥७॥",
                meaning: "Whoever reads this six-syllable hymn in the presence of Shiva, attains the abode of Shiva (Shivaloka) and rejoices with Shiva."
            },
        ],
        aiHint: "shiva shadakshara mantra om namah shivaya six syllables meditation",
        image: `https://picsum.photos/seed/shadakshara/400/225`
    },
    {
        id: "shiva-tandava-stotram",
        title: "Shiva Tandava Stotram",
        sanskritTitle: "शिवताण्डवस्तोत्रम्",
        description: "Describes Shiva’s cosmic Tandava dance and its grandeur.",
        composer: "Ravana",
        deity: "Shiva (Nataraja)",
        verse_count: "16 verses",
        theme: "Describes Shiva’s cosmic Tandava dance and its grandeur.",
        verses: [
             {
                verse: 1,
                sanskrit: "जटाटवीगलज्जलप्रवाहपावितस्थले\nगलेऽवलम्ब्य लम्बितां भुजङ्गतुङ्गमालिकाम् ।\nडमड्डमड्डमड्डमन्निनादवड्डमर्वयं\nचकार चण्डताण्डवं तनोतु नः शिवः शिवम् ॥१॥",
                meaning: "From the forest of his matted locks, water flows and sanctifies the ground. On his neck hangs the high garland of the serpent king. The Damaru drum emits the sound 'Damat, Damat, Damat, Damat'. Shiva performed the fierce Tandava dance – may that Shiva extend auspiciousness to us."
            },
            {
                verse: 2,
                sanskrit: "जटाकटाहसम्भ्रमभ्रमन्निलिम्पनिर्झरी-\n-विलोलवीचिवल्लरीविराजमानमूर्धनि ।\nधगद्धगद्धगज्ज्वलल्ललाटपट्टपावके\nकिशोरचन्द्रशेखरे रतिः प्रतिक्षणं मम ॥२॥",
                meaning: "The celestial river Ganges, swirling in the deep well of his matted hair, moves playfully. His forehead blazes with fire – Dhagad, Dhagad, Dhagad. The crescent moon adorns his head like a jewel. May my delight be in Shiva, moment by moment."
            },
             {
                verse: 3,
                sanskrit: "धराधरेन्द्रनंदिनीविलासबन्धुबन्धुर-\nस्फुरद्दिगन्तसन्ततिप्रमोदमानमानसे ।\nकृपाकटाक्षधोरणीनिरुद्धदुर्धरापदि\nक्वचिद्दिगम्बरे मनो विनोदमेतु वस्तुनि ॥३॥",
                 meaning: "My mind seeks joy in Shiva, whose mind delights in the consort of the mountain king (Parvati). His compassionate glance arrests unbearable hardship. He is the one who wears the directions as his garment (Digambara)."
            },
             {
                verse: 4,
                sanskrit: "जटाभुजङ्गपिङ्गलस्फुरत्फणामणिप्रभा-\nकदम्बकुङ्कुमद्रवप्रलिप्तदिग्वधूमुखे ।\nमदान्धसिन्धुरस्फुरत्त्वगुत्तरीयमेदुरे\nमनो विनोदमद्भुतं बिभर्तु भूतभर्तरि ॥४॥",
                meaning: "May my mind find wonderful delight in the Lord of all beings (Bhūtabhartṛ). The radiant jewel on the hood of the serpent coiled in his matted hair spreads a reddish glow (like kumkuma) on the faces of the Dik-Vadhūs (goddesses of directions). He is covered by the skin of a majestic, intoxicated elephant."
            },
            {
                verse: 5,
                 sanskrit: "सहस्रलोचनप्रभृत्यशेषलेखशेखर-\nप्रसूनधूलिधोरणी विधूसराङ्घ्रिपीठभूः ।\nभुजङ्गराजमालया निबद्धजाटजूटकः\nश्रियै चिराय जायतां चकोरबन्धुशेखरः ॥५॥",
                meaning: "May Shiva, whose footstool is grayed by the dust from flowers fallen from the heads of all gods – Indra (Sahasralochana) and others – whose matted locks are tied by the serpent king garland, and who has the crescent moon (friend of the Chakora bird) as his crest-jewel, grant long-lasting prosperity."
            },
            {
                verse: 6,
                sanskrit:"ललाटचत्वरज्वलद्धनञ्जयस्फुलिङ्गभा-\nनिपीतपञ्चसायकं नमन्निलिम्पनायकम् ।\nसुधामयूखलेखया विराजमानशेखरं\nमहाकपालिसम्पदेशिरोजटालमस्तु नः ॥६॥",
                 meaning: "May we obtain the wealth of Siddhis from the tangled locks of Shiva, whose crest is adorned by the crescent moon (with nectar rays). He consumed the God of Love (Pañchasāyaka) with the sparks of fire blazing on his forehead. He is bowed to by all celestial leaders."
            },
            {
                verse: 7,
                 sanskrit:"करालभालपट्टिकाधगद्धगद्धगज्ज्वल-\nद्धनञ्जयाहुतीकृतप्रचण्डपञ्चसायके ।\nधराधरेन्द्रनन्दिनीकुचाग्रचित्रपत्रक-\n-प्रकल्पनैकशिल्पिनि त्रिलोचने रतिर्मम ॥७॥",
                meaning:"My delight is in the Three-Eyed Lord (Trilochana), who offered the mighty God of Love (Pañchasāyaka) to the fire blazing 'Dhagad, Dhagad' on his terrifying forehead. He is the sole artist capable of drawing decorative lines (patra-rekhas) on the breasts of Parvati, the daughter of the mountain king."
            },
            {
                verse: 8,
                sanskrit:"नवीनमेघमण्डली निरुद्धदुर्धरस्फुरत्-\nकुहूनिशीथिनीतमः प्रबन्धबद्धकन्धरः ।\nनिलिम्पनिर्झरीधरस्तनोतु कृत्तिसिन्धुरः\nकलानिधानबन्धुरः श्रियं जगद्धुरन्धरः ॥८॥",
                meaning:"May Shiva, the bearer of the universe's burden, grant us prosperity. His neck is dark like layers of new clouds on a moonless night (Amavasya). He bears the celestial river. He wears the elephant hide. His crest is adorned by the crescent moon (storehouse of arts)."
            },
             {
                verse: 9,
                sanskrit: "प्रफुल्लनीलपङ्कजप्रपञ्चकालिमप्रभा-\n-वलम्बिकण्ठकन्दलीरुचिप्रबद्धकन्धरम् ।\nस्मरच्छिदं पुरच्छिदं भवच्छिदं मखच्छिदं\nगजच्छिदान्धकच्छिदं तमन्तकच्छिदं भजे ॥९॥",
                 meaning:"I worship Him whose neck, holding the dark glow of the fully bloomed blue lotus series (resembling the universe's darkness), looks beautiful. I worship the destroyer of Manmatha (Smara), the destroyer of Tripura, the destroyer of worldly existence (Bhava), the destroyer of Daksha's sacrifice (Makha), the destroyer of Gajasura, the destroyer of Andhakasura, and the destroyer of Yama (Antaka)."
            },
             {
                verse: 10,
                 sanskrit: "अखर्वसर्वमङ्गलाकलाकदम्बमञ्जरी-\nरसप्रवाहमाधुरी विजृम्भणामधुव्रतम् ।\nस्मरान्तकं पुरान्तकं भवान्तकं मखान्तकं\nगजान्तकान्धकान्तकं तमन्तकान्तकं भजे ॥१०॥",
                 meaning:"I worship Him – the destroyer of Manmatha, Tripura, Bhava, Makha, Gajasura, Andhakasura, and Yama. He is like a bee enjoying the expanding sweetness from the nectar-flow of the cluster of auspicious Kadamba flowers (representing Parvati or auspicious arts)."
            },
            {
                verse: 11,
                 sanskrit: "जयत्वदभ्रविभ्रमभ्रमद्भुजङ्गमश्वस-\nद्विनिर्गमत्क्रमस्फुरत्करालभालहव्यवाट् ।\nधिमिद्धिमिद्धिमिध्वनन्मृदङ्गतुङ्गमङ्गल-\nध्वनिक्रमप्रवर्तितप्रचण्डताण्डवः शिवः ॥११॥",
                meaning:"Victorious is Shiva, whose fierce Tandava dance unfolds step-by-step to the auspicious, high-pitched sounds 'Dhimit, Dhimit, Dhimit' from the Mridanga drum. Fire emanates from His fierce forehead due to the breath of the serpent whirling violently in the sky."
            },
            {
                verse: 12,
                 sanskrit: "दृषद्विचित्रतल्पयोर्भुजङ्गमौक्तिकस्रजोर्-\n-गरिष्ठरत्नलोष्ठयोः सुहृद्विपक्षपक्षयोः ।\nतृणारविन्दचक्षुषोः प्रजामहीमहेन्द्रयोः\nसमं प्रवर्तयन्मनः कदा सदाशिवं भजे ॥१२॥",
                meaning:"When will I worship Lord Sadashiva, the eternally auspicious one, with an equal vision towards diverse paths, a serpent and a pearl garland, the most precious gem and a lump of dirt, a friend and an enemy, a blade of grass and a lotus-eyed person, common people and the emperor?"
            },
            {
                verse: 13,
                 sanskrit: "कदा निलिम्पनिर्झरीनिकुञ्जकोटरे वसन्\nविमुक्तदुर्मतिः सदा शिरः स्थमञ्जलिं वहन् ।\nविलोललोललोचनो ललामभाललग्नकः\nशिवेति मन्त्रमुच्चरन् कदा सुखी भवाम्यहम् ॥१३॥",
                meaning:"When will I be happy, living in a cave near the celestial river Ganga, free from ill thoughts, always holding my hands clasped on my head, with ecstatic, rolling eyes, focused on the forehead mark (tilaka), uttering the mantra 'Shiva'?"
            },
             {
                 verse: 14,
                 sanskrit: "इदम् हि नित्यमेवमुक्तमुत्तमोत्तमं स्तवं\nपठन्स्मरन्ब्रुवन्नरो विशुद्धिमेतिसन्ततम् ।\nहरे गुरौ सुभक्तिमाशु याति नान्यथा गतिं\nविमोहनं हि देहिनां सुशङ्करस्य चिन्तनम् ॥१४॥",
                meaning: "Whoever reads, remembers, and recites this supreme, best stotram daily, attains constant purity. He quickly obtains deep devotion unto Guru Hara (Shiva). There is no other way or refuge. Indeed, contemplation of Shankara is captivating for beings."
            },
            {
                 verse: 15,
                 sanskrit: "पूजावसानसमये दशवक्त्रगीतं\nयः शम्भुपूजनपरं पठति प्रदोषे ।\nतस्य स्थिरां रथगजेन्द्रतुरङ्गयुक्तां\nलक्ष्मीं सदैव सुमुखीं प्रददाति शम्भुः ॥१५॥",
                 meaning: "One who reads this song, sung by the ten-headed Ravana at the end of Shiva puja during Pradosha (twilight), Shambhu always bestows upon him stable prosperity with chariots, elephants, horses, and a pleasing disposition."
            },
        ],
        aiHint: "shiva tandava dance ravana cosmic fierce rhythm",
        image: `https://picsum.photos/seed/shiva-tandava/400/225`
    },
    {
        id: "shivashtakam",
        title: "Shivashtakam",
        sanskritTitle: "शिवाष्टकम्",
        description: "Praises Shiva as the ultimate cause and describes his attributes.",
        composer: "Traditionally attributed to Adi Shankaracharya",
        deity: "Shiva",
        verse_count: "8 verses",
        theme: "Praises Shiva as the ultimate cause and describes his attributes.",
        verses: [
            {
                verse: 1,
                sanskrit: "तस्मै नमः परमकारणकारणाय\nदीप्तोज्ज्वलज्ज्वलितपिङ्गललोचनाय ।\nनागेन्द्रहारकृतकुण्डलभूषणाय\nब्रह्मेन्द्रविष्णुवरदाय नमः शिवाय ॥१॥",
                meaning: "Salutations to Him, the cause of the ultimate cause, whose tawny eyes blaze brightly. Who wears the king of snakes as a necklace and earrings, the bestower of boons to Brahma, Indra, and Vishnu. Salutations to Shiva!",
                transliteration: "Tasmai Namah Parama-Kaaranna-Kaarannaaya\nDiipto[a-U]jjvalaj-Jvalita-Pinggala-Locanaaya |\nNaage[a-I]ndra-Haara-Krta-Kunnddala-Bhuussannaaya\nBrahme[a-I]ndra-Vissnnu-Vara-Daaya Namah Shivaaya ||1||"
            },
            {
                verse: 2,
                sanskrit: "श्रीमत्प्रसन्नशशिपन्नगभूषणाय\nशैलेन्द्रजावदनचुम्बितलोचनाय ।\nकैलासमन्दरमहेन्द्रनिकेतनाय\nलोकत्रयार्तिहरणाय नमः शिवाय ॥२॥",
                meaning: "Salutations to Him, adorned with the radiant, pleasing moon and serpents, whose eyes are kissed by the face of the Mountain Lord's daughter (Parvati). Whose abode is Kailasa, Mandara, and Mahendra mountains. The remover of the afflictions of the three worlds. Salutations to Shiva!",
                transliteration: "Shriimat-Prasanna-Shashi-Pannaga-Bhuussannaaya\nShaile[a-I]ndra-Jaa-Vadana-Cumbita-Locanaaya |\nKailaasa-Mandara-Mahendra-Niketanaaya\nLoka-Traya-[A]arti-Harannaaya Namah Shivaaya ||2||"
            },
            {
                verse: 3,
                sanskrit: "पद्मावदातमणिकुण्डलगोवृषाय\nकृष्णागरुप्रचुरचन्दनचर्चिताय ।\nभस्मानुषक्तविकचोत्पलमल्लिकाय\nनीलाब्जकण्ठसदृशाय नमः शिवाय ॥३॥",
                meaning: "Salutations to Him, whose bull mount has earrings like pure lotus gems, who is smeared with abundant dark Agaru and Sandalwood paste. Who is adorned with sacred ash, blooming lotuses, and jasmine. Whose neck resembles a blue lotus. Salutations to Shiva!",
                transliteration: "Padma-Avadaata-Manni-Kunnddala-Go-Vrssaaya\nKrssnnaagaru-Pracura-Candana-Carcitaaya |\nBhasma-Anussakta-Vikaco[a-U]tpala-Mallikaaya\nNiila-Abja-Kannttha-Sadrshaaya Namah Shivaaya ||3||"
            },
            {
                verse: 4,
                sanskrit: "लम्बत्सपिङ्गलजटामुकुटोत्कटाय\nदंष्ट्राकरालविकटोत्कटभैरवाय ।\nव्याघ्राजिनाम्बरधराय मनोहराय\nत्रैलोक्यनाथनमिताय नमः शिवाय ॥४॥",
                meaning: "Salutations to Him, magnificent with a crown of dangling, tawny matted locks. The fierce Bhairava with terrifying fangs. Who wears a tiger skin garment, the captivating one, bowed to by the Lord of the three worlds. Salutations to Shiva!",
                transliteration: "Lambatsa-Pinggala-Jattaa-Mukutto[a-U]tkattaaya\nDamssttraa-Karaala-Vikatto[a-U]tkatta-Bhairavaaya |\nVyaaghra-Ajina-Ambara-Dharaaya Manoharaaya\nTrai-Lokya-Naatha-Namitaaya Namah Shivaaya ||4||"
            },
            {
                verse: 5,
                sanskrit: "दक्षप्रजापतिमहामखनाशनाय\nक्षिप्रं महात्रिपुरदानवघातनाय ।\nब्रह्मोर्जितोर्ध्वगकरोटिनिकृन्तनाय\nयोगाय योगनमिताय नमः शिवाय ॥५॥",
                meaning: "Salutations to Him, the destroyer of Daksha Prajapati's great sacrifice. The swift slayer of the mighty Tripura demons. Who cut off the upward-gone, powerful skull of Brahma. To Yoga itself, bowed to by Yoga. Salutations to Shiva!",
                transliteration: "Dakssa-Prajaapati-Mahaa-Makha-Naashanaaya\nKssipram Mahaa-Tripura-Daanava-Ghaatanaaya |\nBrahmo[a-Uu]rjito[a-Uu]rdhvaga-Karotti-Nikrntanaaya\nYogaaya Yoga-Namitaaya Namah Shivaaya ||5||"
            },
            {
                verse: 6,
                sanskrit: "संसारसृष्टिघटनापरिवर्तनाय\nरक्षः पिशाचगणसिद्धसमाकुलाय ।\nसिद्धोरगग्रहगणेन्द्रनिषेविताय\nशार्दूलचर्मवसनाय नमः शिवाय ॥६॥",
                meaning: "Salutations to Him, who brings about changes in the events of worldly creation. Who is surrounded by Rakshasas, Pishachas, Ganas, and Siddhas. Served by Siddhas, Uragas (serpents), Grahas (planets), and Gana-Indras. Who wears a tiger skin garment. Salutations to Shiva!",
                transliteration: "Samsaara-Srsstti-Ghattanaa-Parivartanaaya\nRakssah Pishaaca-Ganna-Siddha-Samaakulaaya |\nSiddho(a-U)raga-Graha-Ganne[a-I]ndra-Nissevitaaya\nShaarduula-Carma-Vasanaaya Namah Shivaaya ||6||"
            },
            {
                verse: 7,
                sanskrit: "भस्माङ्गरागकृतरूपमनोहराय\nसौम्यावदातवनमाश्रितमाश्रिताय ।\nगौरीकटाक्षनयनार्धनिरीक्षनाय\nगोक्षीरधारधवलाय नमः शिवाय ॥७॥",
                meaning: "Salutations to Him, whose form is captivating with the application of sacred ash. Who is gentle, pure, resorted to by those dwelling in forests. Who is half-seen by the side-glance of Gauri's eyes. Who is white like streams of cow's milk. Salutations to Shiva!",
                transliteration: "Bhasma-Angga-Raaga-Krta-Ruupa-Manoharaaya\nSaumya-Avadaata-Vanam-Aashritam-Aashritaaya |\nGaurii-Kattaakssa-Nayana-Ardha-Niriikssanaaya\nGo-Kssiira-Dhaara-Dhavalaaya Namah Shivaaya ||7||"
            },
            {
                verse: 8,
                sanskrit: "आदित्यसोमवरुणानिलसेविताय\nयज्ञाग्निहोत्रवरधूमनिकेतनाय ।\nऋक्सामवेदमुनिभिः स्तुतिसंयुताय\nगोपાય गोपनमिताय नमः शिवाय ॥८॥",
                meaning: "Salutations to Him, served by Aditya (Sun), Soma (Moon), Varuna, and Anila (Wind). Whose abode is the sacred smoke of Yajna and Agnihotra. Praised with hymns by the sages of Rig and Sama Vedas. The protector, bowed to by the Gopas (or protectors). Salutations to Shiva!",
                transliteration: "Aaditya-Soma-Varunna-Anila-Sevitaaya\nYajnya-Agnihotra-Vara-Dhuuma-Niketanaaya |\nRk-Saama-Veda-Munibhih Stuti-Samyutaaya\nGopaaya Gopa-Namitaaya Namah Shivaaya ||8||"
            },
            {
                verse: 9,
                sanskrit: "शिवाष्टकमिदं पुण्यं यः पठेच्छिवसन्निधौ ।\nशिवलोकमवाप्नोति शिवेन सह मोदते ॥९॥",
                meaning: "Whoever reads this sacred Shivashtakam in the presence of Shiva, attains the abode of Shiva (Shivaloka) and rejoices with Shiva.",
                transliteration: "Shivaassttakam-Idam Punnyam Yah Patthec-Chiva-Sannidhau |\nShiva-Lokam-Avaapnoti Shivena Saha Modate ||9||"
            }
        ],
        aiHint: "shivashtakam hymn shiva eight verses cause of causes devotion",
        image: `https://picsum.photos/seed/shivashtakam/400/225`
    },
    {
        id: "shiva-pratah-smaran-stotram",
        title: "Shiva Pratah Smaran Stotram",
        sanskritTitle: "शिवप्रातःस्मरणस्तोत्रम्",
        description: "Morning prayer recalling Shiva’s auspicious attributes.",
        composer: "Unknown",
        deity: "Shiva",
        verse_count: "3 verses",
        theme: "Morning prayer recalling Shiva’s auspicious attributes.",
        verses: [
            {
                verse: 1,
                sanskrit: "प्रातः स्मरामि भवभीतिहरं सुरेशं\nगङ्गाधरं वृषभवाहनमम्बिकेशम् ।\nखट्वाङ्गशूलवरदाभयहस्तमीशं\nसंसाररोगहरमौषधमद्वितीयम् ॥१॥",
                meaning: "In the morning, I remember the Lord of Gods (Suresh), the remover of the fear of worldly existence (Bhava-Bhiti), the bearer of Ganga, whose mount is the bull, the Lord of Ambika (Parvati). I remember the Lord who holds a Khatvanga (club with skull), trident, and bestows boons and fearlessness with his hands, the unique medicine that cures the disease of Samsara.",
                transliteration: "Praatah Smaraami Bhava-Bhiiti-Haram Sure[a-Ii]sham\nGanggaa-Dharam Vrssabha-Vaahanam-Ambike[a-Ii]sham |\nKhattvaangga-Shuula-Varada-Abhaya-Hastam-Iisham\nSamsaara-Roga-Haram-Aussadham-Advitiiyam ||1||"
            },
            {
                verse: 2,
                sanskrit: "प्रातर्नमामि गिरिशं गिरिजार्धदेहं\nसर्गस्थितिप्रलयकारणमादिदेवम् ।\nविश्वेश्वरं विजितविश्वमनोभिरामं\nसंसाररोगहरमौषधमद्वितीयम् ॥२॥",
                meaning: "In the morning, I bow to the Lord of the Mountains (Girisha), whose half-body is Girija (Parvati), the primeval God who is the cause of creation, sustenance, and dissolution. I bow to the Lord of the Universe (Vishveshvara), who has conquered the universe, who is pleasing to the mind, the unique medicine that cures the disease of Samsara.",
                transliteration: "Praatar-Namaami Girisham Girija-Ardha-Deham\nSarga-Sthiti-Pralaya-Kaarannam-Aadi-Devam |\nVishva-Iishvaram Vijita-Vishva-Manobhiraamam\nSamsaara-Roga-Haram-Aussadham-Advitiiyam ||2||"
            },
            {
                verse: 3,
                sanskrit: "प्रातर्भजामि शिवमेकमनन्तमाद्यं\nवेदान्तवेद्यमनघं पुरुषं महान्तम् ।\nनामादिभेदरहितं षड्भावशून्यं\nसंसाररोगहरमौषधमद्वितीयम् ॥३॥",
                meaning: "In the morning, I worship Shiva, the One, the endless, the primal being, knowable through Vedanta, the sinless, the great Purusha. Who is devoid of differences like name etc., free from the six states of change (birth, existence, growth, transformation, decay, death), the unique medicine that cures the disease of Samsara.",
                transliteration: "Praatar-Bhajaami Shivam-Ekam-Anantam-Aadyam\nVedaanta-Vedyam-Anagham Purussam Mahaantam |\nNaama-Aadi-Bheda-Rahitam Ssadd-Bhaava-Shuunyam\nSamsaara-Roga-Haram-Aussadham-Advitiiyam ||3||"
            }
        ],
        aiHint: "shiva morning prayer pratah smaran devotion protection",
        image: `https://picsum.photos/seed/pratah-smaran/400/225`
    },
    {
        id: "bilvashtakam",
        title: "Bilvashtakam",
        sanskritTitle: "बिल्वाष्टकम्",
        deity: "Shiva",
        composer: "Attributed to Adi Shankaracharya",
        verse_count: "9 verses",
        theme: "Praises the sacred Bilva leaves offered to Shiva.",
        verses: [
            {
                verse: 1,
                sanskrit: "त्रिदलं त्रिगुणाकारं त्रिनेत्रं च त्रयायुधम् ।\nत्रिजन्मपापसंहारं एकबिल्वं शिवार्पणम् ॥१॥",
                transliteration: "Tridalam Trigunakaram Trinetram Cha Triyayudham |\nTrijanma Papa Samharam Eka Bilvam Shivarpanam ||1||",
                meaning: "I offer a trifoliate Bilva leaf to Lord Shiva, which embodies the three gunas (Sattva, Rajas, Tamas), represents his three eyes, and is like his three-pronged weapon (Trishula). May this offering destroy the sins of my past three lives."
            },
            {
                verse: 2,
                sanskrit: "त्रिशाखैर्बिल्वपत्रैश्च ह्यच्छिद्रैः कोमलैः शुभैः ।\nशिवपूजां करिष्यामि ह्येकबिल्वं शिवार्पणम् ॥२॥",
                transliteration: "Trishakhairbilvapatraishcha Hyachchidraih Komalaih Shubhaih |\nShivapujam Karishyami Hyekabilvam Shivarpanam ||2||",
                meaning: "With Bilva leaves of three shoots, which are untorn, soft, and auspicious, I shall perform the worship of Lord Shiva. I offer a single Bilva leaf to Lord Shiva."
            },
            {
                verse: 3,
                sanskrit: "अखण्डबिल्वपत्रेण पूजिते नन्दिकेश्वरे ।\nशुद्ध्यन्ति सर्वपापेभ्यो ह्येकबिल्वं शिवार्पणम् ॥३॥",
                transliteration: "Akhanda Bilva Patrena Pujite Nandikeshware |\nShudhyanti Sarva Papebhyo Hyeka Bilvam Shivarpanam ||3||",
                meaning: "By worshipping Nandikeshvara with an unbroken Bilva leaf, all sins are purified. I offer a single Bilva leaf to Lord Shiva."
            },
            {
                verse: 4,
                sanskrit: "शालिग्रामशिलामेकां विप्राणां जातु अर्पयेत् ।\nसोमयज्ञमहापुण्यं एकबिल्वं शिवार्पणम् ॥४॥",
                transliteration: "Shaligrama Shilamekam Vipranam Jatu Arpayet |\nSomayajna Mahapunyam Eka Bilvam Shivarpanam ||4||",
                meaning: "Offering a single Bilva leaf to Lord Shiva is as meritorious as offering a Shaligrama stone to learned Brahmins or performing the great Soma Yajna."
            },
            {
                verse: 5,
                sanskrit: "दन्तिकोटिसहस्राणि वाजपेयेशतानि च ।\nकोटिकन्यामहादानं एकबिल्वं शिवार्पणम् ॥५॥",
                transliteration: "Dantikoti Sahasrani Vajapeya Shatani Cha |\nKoti Kanya Mahadanam Eka Bilvam Shivarpanam ||5||",
                meaning: "Offering a single Bilva leaf to Lord Shiva is as great as the charity of donating thousands of elephants, performing hundreds of Vajapeya sacrifices, or gifting millions of virgins in marriage."
            },
            {
                verse: 6,
                sanskrit: "लक्ष्म्याः स्तनत उत्पन्नं महादेवस्य च प्रियम् ।\nबिल्ववृक्षं प्रयच्छामि ह्येकबिल्वं शिवार्पणम् ॥६॥",
                transliteration: "Lakshmyah Stanamautpannam Mahadevasya Cha Priyam |\nBilva Vriksham Prayachhami Hyeka Bilvam Shivarpanam ||6||",
                meaning: "Born from the bosom of Goddess Lakshmi and dear to Lord Mahadeva, I offer the Bilva tree (its leaf). I offer a single Bilva leaf to Lord Shiva."
            },
            {
                verse: 7,
                sanskrit: "दर्शनं बिल्ववृक्षस्य स्पर्शनं पापनाशनम् ।\nअघोरपापसंहारं एकबिल्वं शिवार्पणम् ॥७॥",
                transliteration: "Darshanam Bilva Vrikshasya Sparshanam Papa Nashanam |\nAghora Papa Samharam Eka Bilvam Shivarpanam ||7||",
                meaning: "The mere sight of a Bilva tree, and touching it, destroys sins. It destroys even the most terrible sins. I offer a single Bilva leaf to Lord Shiva."
            },
            {
                verse: 8,
                sanskrit: "मूलतो ब्रह्मरूपाय मध्यतो विष्णुरूपिणे ।\nअग्रतः शिवरूपाय ह्येकबिल्वं शिवार्पणम् ॥८॥",
                transliteration: "Mulato Brahma Rupaya Madhyato Vishnu Rupine |\nAgratah Shiva Rupaya Hyeka Bilvam Shivarpanam ||8||",
                meaning: "I offer a single Bilva leaf to Lord Shiva, which at its base is the form of Brahma, in the middle is the form of Vishnu, and at its tip is the form of Shiva himself."
            },
            {
                verse: 9,
                sanskrit: "बिल्वाष्टकमिदं पुण्यं यः पठेच्छिवसन्निधौ ।\nसर्वपापविनिर्मुक्तः शिवलोकमवाप्नुयात् ॥९॥",
                transliteration: "Bilvashtakamidam Punyam Yah Pathet Shivasannidhau |\nSarvapapavinirmuktah Shivlokamavapnuyat ||9||",
                meaning: "Whoever reads this sacred Bilvashtakam in the presence of Shiva will be freed from all sins and will attain the abode of Shiva."
            }
        ],
        description: "Praises the sacred Bilva leaves offered to Shiva.",
        aiHint: "shiva bilva leaves worship sacred offering",
        image: `https://picsum.photos/seed/bilvashtakam/400/225`
    },
    {
        id: "shivasahasranama-stotram",
        title: "Shivasahasranama Stotram",
        sanskritTitle: "शिवसहस्रनाम स्तोत्रम्",
        deity: "Shiva",
        composer: "Puranic source (Mahabharata)",
        verse_count: "1000+ names",
        theme: "Enumerates the thousand names of Shiva, each representing a divine quality.",
        verses: [
            {
                verse: 1,
                sanskrit: "स्थिरः स्थाणुः प्रभुर्भीमः प्रवरो वरदो वरः ।",
                transliteration: "Sthiraḥ Sthāṇuḥ Prabhurbhīmaḥ Pravaro Varado Varaḥ",
                meaning: "The Fixed, The Pillar, The Lord, The Formidable, The Excellent, The Boon-Giver, The Best."
            },
            {
                verse: 2,
                sanskrit: "सर्वात्मा सर्वविख्यातः सर्वः सर्वकरो भवः ॥",
                transliteration: "Sarvātmā Sarvavikhyātaḥ Sarvaḥ Sarvakaro Bhavaḥ",
                meaning: "The Soul of All, The All-Known, The All, The Doer of All, The Existence."
            },
            {
                verse: 3,
                sanskrit: "जटी चर्मी शिखण्डी च सर्वाङ्गः सर्वभावनः ।",
                transliteration: "Jaṭī Carmī Śikhaṇḍī ca Sarvāṅgaḥ Sarvabhāvanaḥ",
                meaning: "The One with Matted Hair, The One with Skin (as garment), The One with a Tuft, The One with All Limbs, The Creator of All."
            },
            {
                verse: 4,
                sanskrit: "हरश्च हरिणाक्षश्च सर्वभूतहरः प्रभुः ॥",
                transliteration: "Haraśca Hariṇākṣaśca Sarvabhūtaharaḥ Prabhuḥ",
                meaning: "The Destroyer, The Deer-Eyed, The Destroyer of All Beings, The Lord."
            },
            {
                verse: 5,
                sanskrit: "प्रवृत्तिश्च निवृत्तिश्च नियतः शाश्वतो ध्रुवः ।",
                transliteration: "Pravṛttiśca Nivṛttiśca Niyataḥ Śāśvato Dhruvaḥ",
                meaning: "The Active, The Inactive, The Controlled, The Eternal, The Immovable."
            },
            {
                verse: 6,
                sanskrit: "श्मशानवासी भगवान् खचरो गोचरोऽर्दनः ॥",
                transliteration: "Śmaśānavāsī Bhagavān Khacaro Gocaro'rdanaḥ",
                meaning: "The Dweller in Cremation Grounds, The Divine One, The Sky-Wanderer, The Perceptible, The Punisher."
            },
            {
                verse: 7,
                sanskrit: "अभिवाद्यो महाकर्मा तपस्वी भूतभावनः ।",
                transliteration: "Abhivādyo Mahākarmā Tapasvī Bhūtabhāvanaḥ",
                meaning: "The Worthy of Salutation, The Great in Action, The Ascetic, The Creator of Beings."
            },
            {
                verse: 8,
                sanskrit: "उन्मत्तवेषप्रच्छन्नः सर्वलोकप्रजापतिः ॥",
                transliteration: "Unmattaveṣapracchannaḥ Sarvalokaprajāpatiḥ",
                meaning: "The One disguised in the attire of a madman, The Lord of All Worlds and Beings."
            },
            {
                verse: 9,
                sanskrit: "महारूपो महाकायो वृषरूपो महायशाः ।",
                transliteration: "Mahārūpo Mahākāyo Vṛṣarūpo Mahāyaśāḥ",
                meaning: "The One with a Great Form, The One with a Great Body, The One in the Form of a Bull, The One of Great Fame."
            },
            {
                verse: 10,
                sanskrit: "महात्मा सर्वभूतात्मा विश्वरूपो महाहनुः ॥",
                transliteration: "Mahātmā Sarvabhūtātmā Viśvarūpo Mahāhanuḥ",
                meaning: "The Great Soul, The Soul of All Beings, The Universal Form, The One with a Great Jaw."
            }
        ],
        description: "The Shivasahasranama enumerates one thousand names of Lord Shiva, with each name highlighting a different attribute of the divine. This stotra, found in the Anushasana Parva of the Mahabharata, is a profound hymn of praise. The verses listed here are just a small selection of the thousand names.",
        aiHint: "shiva sahasranama thousand names divine qualities mahabharata",
        image: `https://picsum.photos/seed/sahasranama/400/225`
    },
    {
        id: "vishwanathashtakam",
        title: "Vishwanathashtakam",
        sanskritTitle: "विश्वनाथाष्टकम्",
        deity: "Shiva (Vishwanatha of Kashi)",
        composer: "Adi Shankaracharya",
        verse_count: "8 verses",
        theme: "Praises Lord Vishwanatha of Kashi as the granter of liberation.",
        verses: [
            {
                verse: 1,
                sanskrit: "गङ्गातरङ्गरमणीयजटाकलापं\nगौरीनिरन्तरविभूषितवामभागम् ।\nनारायणप्रियमनङ्गमदापहारं\nवाराणसीपुरपतिं भज विश्वनाथम् ॥१॥",
                transliteration: "Ganga Taranga Ramaniya Jata Kalapam\nGauri Nirantara Vibhushita Vama Bhagam |\nNarayana Priyam Ananga Madapaharam\nVaranasi Pura Patim Bhaja Vishvanatham ||1||",
                meaning: "Worship Vishwanatha, the Lord of Varanasi, whose matted locks are beautified by the waves of the Ganga, whose left side is eternally adorned by Gauri (Parvati), who is dear to Narayana (Vishnu), and who destroyed the pride of the God of Love (Ananga)."
            },
            {
                verse: 2,
                sanskrit: "वाचामगोचरमनेकगुणस्वरूपं\nवागीशविष्णुसुरसेवितपादपीठम् ।\nवामेन विग्रहवरेण कलत्रवन्तं\nवाराणसीपुरपतिं भज विश्वनाथम् ॥२॥",
                transliteration: "Vacham Agocharam Aneka Guna Swarupam\nVagisha Vishnu Sura Sevita Pada Pitham |\nVamena Vigraha Varena Kalatravantam\nVaranasi Pura Patim Bhaja Vishvanatham ||2||",
                meaning: "Worship Vishwanatha, the Lord of Varanasi, who is beyond speech, whose nature has manifold qualities, whose footstool is served by Brahma, Vishnu, and other gods, and who possesses a consort (Parvati) in his excellent left half-form (Ardhanarishvara)."
            },
            {
                verse: 3,
                sanskrit: "भूताधिपं भुजगभूषणभूषिताङ्गं\nव्याघ्राजिनाम्बरधरं जटिलं त्रिनेत्रम् ।\nपाशाङ्कुशाभयवरप्रदशूलपाणिं\nवाराणसीपुरपतिं भज विश्वनाथम् ॥३॥",
                transliteration: "Bhutadhipam Bhujaga Bhushana Bhushitangam\nVyaghrajinambaradharam Jatilam Trinetram |\nPashankushabhaya Varaprada Shulapanim\nVaranasi Pura Patim Bhaja Vishvanatham ||3||",
                meaning: "Worship Vishwanatha, the Lord of Varanasi, the lord of all beings, whose body is adorned with serpent ornaments, who wears a tiger skin, has matted hair, and three eyes. Who holds a noose, a goad, a trident, and bestows the gestures of fearlessness and boons."
            },
            {
                verse: 4,
                sanskrit: "शीतांशुशोभितकिरीटविराजमानं\nभालेक्षणानलविशोषितपञ्चबाणम् ।\nनागाधिपारचितभासुरकर्णपूरं\nवाराणसीपुरपतिं भज विश्वनाथम् ॥४॥",
                transliteration: "Shitamshu Shobhita Kirita Virajamanam\nBhalekshananala Vishoshita Panchabanam |\nNagadhipa Rachita Bhasura Karnapuram\nVaranasi Pura Patim Bhaja Vishvanatham ||4||",
                meaning: "Worship Vishwanatha, the Lord of Varanasi, who shines with a crown beautified by the cool-rayed moon, who dried up the five-arrowed God of Love with the fire from his forehead eye, and whose brilliant ear-ornaments are fashioned by the serpent king."
            },
            {
                verse: 5,
                sanskrit: "पञ्चाननं दुरितमत्तमतङ्गजानां\nनागान्तकं दनुजपुङ्गवपन्नगानाम् ।\nदावानलं मरणशोकजराटवीनां\nवाराणसीपुरपतिं भज विश्वनाथम् ॥५॥",
                transliteration: "Panchananam Durita Matta Matangajanam\nNagantakam Danuja Pungava Pannaganam |\nDavanalam Marana Shoka Jaratavinam\nVaranasi Pura Patim Bhaja Vishvanatham ||5||",
                meaning: "Worship Vishwanatha, the Lord of Varanasi, the five-faced one, who is like a lion (destroyer) to the intoxicated elephants of sin, a destroyer of demons, great men, and serpents. He is a forest fire to the forests of death, sorrow, and old age."
            },
            {
                verse: 6,
                sanskrit: "तेजोमयं सगुणनिर्गुणमद्वितीयम्\nआनन्दकन्दमपराजितमप्रमेयम् ।\nनागात्मकं सकलनिष्कलमात्मरूपं\nवाराणसीपुरपतिं भज विश्वनाथम् ॥६॥",
                transliteration: "Tejomayam Saguna Nirgunam Advitiyam\nAnandakandam Aparajitam Aprameyam |\nNagatmakam Sakala Nishkalam Atmarupam\nVaranasi Pura Patim Bhaja Vishvanatham ||6||",
                meaning: "Worship Vishwanatha, the Lord of Varanasi, who is full of light, with and without attributes, the non-dual one. The root of bliss, unconquered, immeasurable. Whose form is the serpent, who is both with and without parts, the very form of the Self."
            },
            {
                verse: 7,
                sanskrit: "आशां विहाय परिहृत्य परस्य निन्दां\nपापे रतिं च सुनिवार्य मनः समाधौ ।\nआदाय हृत्कमलमध्यगतं परेशं\nवाराणसीपुरपतिं भज विश्वनाथम् ॥७॥",
                transliteration: "Asham Vihaya Parihritya Parasya Nindam\nPape Ratim Cha Sunivarya Manah Samadhau |\nAadaya Hritkamalamadhyagatam Paresham\nVaranasi Pura Patim Bhaja Vishvanatham ||7||",
                meaning: "Having abandoned desires, having given up slandering others, having completely checked the mind's attachment to sin and fixing it in meditation; holding the Supreme Lord in the center of the heart-lotus, worship Vishwanatha, the Lord of Varanasi."
            },
            {
                verse: 8,
                sanskrit: "रागादिदोषरहितं स्वजनानुरागं\nवैराग्यशान्तिनिलयं गिरिजासहायम् ।\nमाधुर्यधैर्यसुभगं गरलाभिरामं\nवाराणसीपुरपतिं भज विश्वनाथम् ॥८॥",
                transliteration: "Ragadi Dosha Rahitam Swajananuragam\nVairagya Shanti Nilayam Girija Sahayam |\nMadhurya Dhairya Subhagam Garalabhiramam\nVaranasi Pura Patim Bhaja Vishvanatham ||8||",
                meaning: "Worship Vishwanatha, the Lord of Varanasi, who is free from faults like attachment, yet is affectionate to his own people. He is the abode of detachment and peace, the companion of Girija (Parvati). He is charming with sweetness and courage, and beautiful with the poison in his throat."
            },
            {
                verse: 9,
                sanskrit: "वाराणसीपुरपतेः स्तवनं शिवस्य\nयः पठेत् सुक्रियया अष्टकमिदं नरः ।\nस विनीय सर्वपापान् शिवलोकमवाप्नुयात्\nशिवेन सह मोदते ॥९॥",
                transliteration: "Varanasi Pura Pateh Stavanam Shivasya\nYah Pathet Sukriyaya Ashtakamidam Narah |\nSa Viniya Sarvapapan Shivalokamavapnuyat\nShivena Saha Modate ||9||",
                meaning: "That person who, with good deeds, recites this hymn of eight verses to Shiva, the Lord of Varanasi, having cast off all sins, attains the world of Shiva and rejoices with Shiva."
            }
        ],
        description: "Praises Lord Vishwanatha of Kashi as the granter of liberation.",
        aiHint: "shiva vishwanatha kashi liberation ashtakam",
        image: `https://picsum.photos/seed/vishwanathashtakam/400/225`
    },
    {
        id: "shankara-ashtakam",
        title: "Shankara Ashtakam",
        sanskritTitle: "शङ्कराष्टकम्",
        deity: "Shiva (Shankara)",
        composer: "Adi Shankaracharya",
        verse_count: "8 verses",
        theme: "Devotional praise to Shankara’s compassion and supreme nature.",
        verses: [
            {
                verse: 1,
                sanskrit: "तस्मै नमः परमकारणकारणाय\nदीप्तोज्ज्वलज्ज्वलितपिङ्गललोचनाय ।\nनागेन्द्रहारकृतकुण्डलभूषणाय\nब्रह्मेन्द्रविष्णुवरदाय नमः शिवाय ॥१॥",
                meaning: "Salutations to Him, the cause of the ultimate cause, whose tawny eyes blaze brightly. Who wears the king of snakes as a necklace and earrings, the bestower of boons to Brahma, Indra, and Vishnu. Salutations to Shiva!",
                transliteration: "Tasmai Namah Parama-Kaaranna-Kaarannaaya\nDiipto[a-U]jjvalaj-Jvalita-Pinggala-Locanaaya |\nNaage[a-I]ndra-Haara-Krta-Kunnddala-Bhuussannaaya\nBrahme[a-I]ndra-Vissnnu-Vara-Daaya Namah Shivaaya ||1||"
            },
            {
                verse: 2,
                sanskrit: "श्रीमत्प्रसन्नशशिपन्नगभूषणाय\nशैलेन्द्रजावदनचुम्बितलोचनाय ।\nकैलासमन्दरमहेन्द्रनिकेतनाय\nलोकत्रयार्तिहरणाय नमः शिवाय ॥२॥",
                meaning: "Salutations to Him, adorned with the radiant, pleasing moon and serpents, whose eyes are kissed by the face of the Mountain Lord's daughter (Parvati). Whose abode is Kailasa, Mandara, and Mahendra mountains. The remover of the afflictions of the three worlds. Salutations to Shiva!",
                transliteration: "Shriimat-Prasanna-Shashi-Pannaga-Bhuussannaaya\nShaile[a-I]ndra-Jaa-Vadana-Cumbita-Locanaaya |\nKailaasa-Mandara-Mahendra-Niketanaaya\nLoka-Traya-[A]arti-Harannaaya Namah Shivaaya ||2||"
            },
            {
                verse: 3,
                sanskrit: "पद्मावदातमणिकुण्डलगोवृषाय\nकृष्णागरुप्रचुरचन्दनचर्चिताय ।\nभस्मानुषक्तविकचोत्पलमल्लिकाय\nनीलाब्जकण्ठसदृशाय नमः शिवाय ॥३॥",
                meaning: "Salutations to Him, whose bull mount has earrings like pure lotus gems, who is smeared with abundant dark Agaru and Sandalwood paste. Who is adorned with sacred ash, blooming lotuses, and jasmine. Whose neck resembles a blue lotus. Salutations to Shiva!",
                transliteration: "Padma-Avadaata-Manni-Kunnddala-Go-Vrssaaya\nKrssnnaagaru-Pracura-Candana-Carcitaaya |\nBhasma-Anussakta-Vikaco[a-U]tpala-Mallikaaya\nNiila-Abja-Kannttha-Sadrshaaya Namah Shivaaya ||3||"
            },
            {
                verse: 4,
                sanskrit: "लम्बत्सपिङ्गलजटामुकुटोत्कटाय\nदंष्ट्राकरालविकटोत्कटभैरवाय ।\nव्याघ्राजिनाम्बरधराय मनोहराय\nत्रैलोक्यनाथनमिताय नमः शिवाय ॥४॥",
                meaning: "Salutations to Him, magnificent with a crown of dangling, tawny matted locks. The fierce Bhairava with terrifying fangs. Who wears a tiger skin garment, the captivating one, bowed to by the Lord of the three worlds. Salutations to Shiva!",
                transliteration: "Lambatsa-Pinggala-Jattaa-Mukutto[a-U]tkattaaya\nDamssttraa-Karaala-Vikatto[a-U]tkatta-Bhairavaaya |\nVyaaghra-Ajina-Ambara-Dharaaya Manoharaaya\nTrai-Lokya-Naatha-Namitaaya Namah Shivaaya ||4||"
            },
            {
                verse: 5,
                sanskrit: "दक्षप्रजापतिमहामखनाशनाय\nक्षिप्रं महात्रिपुरदानवघातनाय ।\nब्रह्मोर्जितोर्ध्वगकरोटिनिकृन्तनाय\nयोगाय योगनमिताय नमः शिवाय ॥५॥",
                meaning: "Salutations to Him, the destroyer of Daksha Prajapati's great sacrifice. The swift slayer of the mighty Tripura demons. Who cut off the upward-gone, powerful skull of Brahma. To Yoga itself, bowed to by Yoga. Salutations to Shiva!",
                transliteration: "Dakssa-Prajaapati-Mahaa-Makha-Naashanaaya\nKssipram Mahaa-Tripura-Daanava-Ghaatanaaya |\nBrahmo[a-Uu]rjito[a-Uu]rdhvaga-Karotti-Nikrntanaaya\nYogaaya Yoga-Namitaaya Namah Shivaaya ||5||"
            },
            {
                verse: 6,
                sanskrit: "संसारसृष्टिघटनापरिवर्तनाय\nरक्षः पिशाचगणसिद्धसमाकुलाय ।\nसिद्धोरगग्रहगणेन्द्रनिषेविताय\nशार्दूलचर्मवसनाय नमः शिवाय ॥६॥",
                meaning: "Salutations to Him, who brings about changes in the events of worldly creation. Who is surrounded by Rakshasas, Pishachas, Ganas, and Siddhas. Served by Siddhas, Uragas (serpents), Grahas (planets), and Gana-Indras. Who wears a tiger skin garment. Salutations to Shiva!",
                transliteration: "Samsaara-Srsstti-Ghattanaa-Parivartanaaya\nRakssah Pishaaca-Ganna-Siddha-Samaakulaaya |\nSiddho(a-U)raga-Graha-Ganne[a-I]ndra-Nissevitaaya\nShaarduula-Carma-Vasanaaya Namah Shivaaya ||6||"
            },
            {
                verse: 7,
                sanskrit: "भस्माङ्गरागकृतरूपमनोहराय\nसौम्यावदातवनमाश्रितमाश्रिताय ।\nगौरीकटाक्षनयनार्धनिरीक्षनाय\nगोक्षीरधारधवलाय नमः शिवाय ॥७॥",
                meaning: "Salutations to Him, whose form is captivating with the application of sacred ash. Who is gentle, pure, resorted to by those dwelling in forests. Who is half-seen by the side-glance of Gauri's eyes. Who is white like streams of cow's milk. Salutations to Shiva!",
                transliteration: "Bhasma-Angga-Raaga-Krta-Ruupa-Manoharaaya\nSaumya-Avadaata-Vanam-Aashritam-Aashritaaya |\nGaurii-Kattaakssa-Nayana-Ardha-Niriikssanaaya\nGo-Kssiira-Dhaara-Dhavalaaya Namah Shivaaya ||7||"
            },
            {
                verse: 8,
                sanskrit: "आदित्यसोमवरुणानिलसेविताय\nयज्ञाग्निहोत्रवरधूमनिकेतनाय ।\nऋक्सामवेदमुनिभिः स्तुतिसंयुताय\nगोपાય गोपनमिताय नमः शिवाय ॥८॥",
                meaning: "Salutations to Him, served by Aditya (Sun), Soma (Moon), Varuna, and Anila (Wind). Whose abode is the sacred smoke of Yajna and Agnihotra. Praised with hymns by the sages of Rig and Sama Vedas. The protector, bowed to by the Gopas (or protectors). Salutations to Shiva!",
                transliteration: "Aaditya-Soma-Varunna-Anila-Sevitaaya\nYajnya-Agnihotra-Vara-Dhuuma-Niketanaaya |\nRk-Saama-Veda-Munibhih Stuti-Samyutaaya\nGopaaya Gopa-Namitaaya Namah Shivaaya ||8||"
            },
            {
                verse: 9,
                sanskrit: "शिवाष्टकमिदं पुण्यं यः पठेच्छिवसन्निधौ ।\nशिवलोकमवाप्नोति शिवेन सह मोदते ॥९॥",
                meaning: "Whoever reads this sacred Shivashtakam in the presence of Shiva, attains the abode of Shiva (Shivaloka) and rejoices with Shiva.",
                transliteration: "Shivaassttakam-Idam Punnyam Yah Patthec-Chiva-Sannidhau |\nShiva-Lokam-Avaapnoti Shivena Saha Modate ||9||"
            }
        ],
        description: "Devotional praise to Shankara’s compassion and supreme nature.",
        aiHint: "shiva shankara ashtakam compassion devotion",
        image: `https://picsum.photos/seed/shankara-ashtakam/400/225`
    },
    {
        id: "gangashtakam",
        title: "Gangashtakam",
        sanskritTitle: "गङ्गाष्टकम्",
        deity: "Ganga on Shiva's head",
        composer: "Adi Shankaracharya",
        verse_count: "8 verses",
        theme: "Praises the divine river Ganga as flowing from Shiva’s locks.",
        verses: [
            {
                verse: 1,
                sanskrit: "भगवति तव तीरे नीरमात्राशनोऽहं\nविगतविषयतृष्णः कृष्णमाराधयामि ।\nसकलकलुषभङ्गे स्वर्गसोपानसङ्गे\nतरलतरतरङ्गे देवि गङ्गे प्रसीद ॥१॥",
                transliteration: "Bhagavati tava tīre nīramātrāśano'haṁ vigataviṣayatṛṣṇaḥ kṛṣṇamārādhayāmi |\nSakalakaluṣabhaṅge svargasopānasaṅge taralatarataraṅge devi gaṅge prasīda ||1||",
                meaning: "O Goddess Bhagavati Ganga, residing on your banks, consuming only water, I worship Krishna with my desires for worldly objects gone. O demolisher of all sins, the ladder to heaven, with your gently moving waves, O Devi Ganga, be pleased with me."
            },
            {
                verse: 2,
                sanskrit: "भगवति भवलीलामौलिमाले तवाम्भः\nकणमणुपरिमाणं प्राणिनो ये स्पृशन्ति ।\nअमरनगरनारीचामरग्राहिणीनां\nविगतकलिकलङ्कातङ्कमङ्के लुठन्ति ॥२॥",
                transliteration: "Bhagavati bhavalīlāmaulimāle tavāmbhaḥ kaṇamaṇuparimāṇaṁ prāṇino ye spṛśanti |\nAmaranagaranārīcāmaragrāhiṇīnāṁ vigatakalikalankātaṅkamaṅke luṭhanti ||2||",
                meaning: "O Goddess Bhagavati, you are the garland on the head of Lord Shiva. Those beings who touch even a tiny drop of your water, roll in the laps of the celestial maidens of the city of gods, free from the stains and fears of the Kali Yuga."
            },
            {
                verse: 3,
                sanskrit: "ब्रह्माण्डं खण्डयन्ती हरशिरसि जटावल्लिमुल्लासयन्ती\nस्वर्लोकादापतन्ती कनकगिरिगुहागण्डशैलात्स्खलन्ती ।\nक्षोणीपृष्ठे लुठन्ती दुरितचयचमूर्निर्भरं भर्त्सयन्ती\nपाथोधिं पूरयन्ती सुरनगरसरित्पावनी नः पुनातु ॥३॥",
                transliteration: "Brahmāṇḍaṁ khaṇḍayantī haraśirasi jaṭāvallimullāsayantī svarlokādāpatantī kanakagiriguhāgaṇḍaśailātskhayantī | Kṣoṇīpṛṣṭhe luṭhantī duritacayacamūrnirbharaṁ bhartsayantī pāthodhiṁ pūrayantī suranagarasaritpāvanī naḥ punātu ||3||",
                meaning: "Splitting the universe, she playfully animates the creepers of Shiva's matted hair, descending from heaven, stumbling from the cave-like rocks of the golden mountain (Meru). Rolling on the earth, she fiercely rebukes the armies of sins, filling the ocean. May that purifying river of the city of gods cleanse us."
            },
            {
                verse: 4,
                sanskrit: "मज्जन्मातङ्गकुम्भच्युतमदमदिरामोदमत्तालिजालं\nस्नानैः सिद्धाङ्गनानां कुचयुगविगलत्कुङ्कुमासङ्गपिङ्गम् ।\nसायं प्रातर्मुनीनां कुशकुसुमचयैश्छिन्नसंकीर्णतीरं\nपायन्नो गाङ्गमम्भः करिकलभमुखाक्रान्तशैवालजालम् ॥४॥",
                transliteration: "Majjanmātaṅgakumbhacyutamadamadirāmodamattāli jālaṁ snānaiḥ siddhāṅganānāṁ kucayugavigalatkuṅkumāsaṅgapiṅgam | Sāyaṁ prātarmunīnāṁ kuśakusumacayaiśchinnasaṁkīrṇatīraṁ pāyanno gāṅgamambhaḥ karikalabhamukhākrāntaśaivālajālam ||4||",
                meaning: "May the waters of the Ganga protect us, filled with swarms of bees intoxicated by the fragrance of the ichor-wine flowing from the temples of elephants plunging into it; yellowed by the saffron from the breasts of Siddha women bathing; its banks crowded in the morning and evening with Kusha grass and flowers gathered by sages; its mossy carpets disturbed by the mouths of young elephants."
            },
            {
                verse: 5,
                sanskrit: "आदावादिपितामहस्य नियमव्यापारपारे जलं\nपश्चात्पन्नगशायिनो भगवतः पादोदकं पावनम् ।\nभूयः शम्भुजटाविभूषणमणोर्धन्येयमुर्वीतले\nदेवी त्रिपथगामिनी भगवती भागीरथी दृश्यते ॥५॥",
                transliteration: "Ādāvādipitāmahasya niyamavyāpārapāre jalaṁ paścātpannagaśāyino bhagavataḥ pādodakaṁ pāvanam | Bhūyaḥ śambhujatāvibhūṣaṇamaṇordhanyeyamurvītale devī tripathagāminī bhagavatī bhāgīrathī dṛśyate ||5||",
                meaning: "First, this water was in the kamandalu of the first great father (Brahma) for his ritual duties. Then, it became the purifying water that washed the feet of the Lord who sleeps on a serpent (Vishnu). Again, it became the jewel adorning the matted hair of Shambhu (Shiva). Blessed is this Devi on earth, the divine Bhagirathi who flows in three paths."
            },
            {
                verse: 6,
                sanskrit: "शैलान्नन्दिनि ते कदा खलु चिरं स्नेहेन विन्ध्याटवी\nगह्वारेषु वसामि तोयतरलैर्हिंस्रैः समं जन्तुभिः ।\nत्यक्त्वा सर्वजनानुकूलविषयं ग्रामं पुरं पत्तनं\nधन्ये पुण्यवति प्रियेऽत्र भवति प्रेम्णा तव श्यामिका ॥६॥",
                transliteration: "Śailānnandini te kadā khalu ciraṁ snehena vindhyāṭavī gahvāreṣu vasāmi toyataralairhiṁsraiḥ samaṁ jantubhiḥ | Tyaktvā sarvajanānukūlaviṣayaṁ grāmaṁ puraṁ pattanaṁ dhanye puṇyavati priye'tra bhavati premṇā tava śyāmikā ||6||",
                meaning: "O daughter of the mountain! When will I live for a long time with affection in the caves of the Vindhya forest, along with the wild animals living on your moving waters? Leaving behind villages, cities, and towns that cater to all people, O blessed, holy, and dear one, may I become your loving servant here."
            },
            {
                verse: 7,
                sanskrit: "अपि प्राज्यं राज्यं तृणमिव परित्यज्य सहसा\nविलीये भावेन त्वदतुलसुखाम्भोरुहवने ।\nरसारङ्गे गङ्गे त्रिभुवनशरीरेऽखिलसुखे\nपुनर्जन्मक्लेशं न खलु लभते त्वद्भजनतः ॥७॥",
                transliteration: "Api prājyaṁ rājyaṁ tṛṇamiva parityajya sahasā vilīye bhāvena tvadaturasukhāmbhoruhavane | Rasāraṅge gaṅge tribhuvanaśarīre'khilasukhē punarjanmakleśaṁ na khalu labhate tvadbhajanataḥ ||7||",
                meaning: "Giving up even a great kingdom like a blade of grass, may I instantly dissolve with devotion in the lotus-forest of your incomparable bliss. O Ganga, the stage for spiritual aesthetics, body of the three worlds, the source of all happiness! By worshipping you, one certainly does not receive the pains of rebirth."
            },
            {
                verse: 8,
                sanskrit: "गङ्गाष्टकमिदं पुण्यं यः पठेत्प्रयतो नरः ।\nसर्वपापविनिर्मुक्तो विष्णुलोकं स गच्छति ॥८॥",
                transliteration: "Gaṅgāṣṭakamidaṁ puṇyaṁ yaḥ paṭhetprayato naraḥ | Sarvapāpavinirmukto viṣṇulokaṁ sa gacchati ||8||",
                meaning: "The devoted person who reads this sacred Gangashtakam, freed from all sins, goes to the abode of Vishnu (Vishnuloka)."
            }
        ],
        description: "Praises the divine river Ganga as flowing from Shiva’s locks.",
        aiHint: "ganga river shiva ashtakam sacred water",
        image: `https://picsum.photos/seed/gangashtakam/400/225`
    },
    {
        id: "narmadashtakam",
        title: "Narmadashtakam",
        sanskritTitle: "नर्मदाष्टकम्",
        deity: "River Narmada (linked to Shiva worship)",
        composer: "Adi Shankaracharya",
        verse_count: "9 verses",
        theme: "Glorifies the sanctity and purifying power of the Narmada.",
        verses: [
            {
                verse: 1,
                sanskrit: "सबिन्दुसिन्धुसुस्खलत्तरङ्गभङ्गरञ्जितं\nद्विषत्सु पापजातजातकारिवारिसंयुतम् ।\nकृतान्तदूतकालभूतभीतिहारिवर्मदे\nत्वदीयपादपङ्कजं नमामि देवि नर्मदे ॥१॥",
                transliteration: "Sabindusindhususkhalattaraṅgabhaṅgarañjitaṁ dviṣatsu pāpajātajātakārivārisaṁyutam | Kṛtāntadūtakālabhūtabhītihārivarmade tvadīyapādapaṅkajaṁ namāmi devi narmade ||1||",
                meaning: "O Devi Narmada, whose form is beautified by the gracefully moving waves of the ocean, and whose waters destroy the sins of enemies. O provider of a protective shield against the fear of death's messengers, ghosts, and time itself, I bow to Your lotus feet."
            },
            {
                verse: 2,
                sanskrit: "त्वदम्बु लीनदीनमीनदिव्यसम्प्रदायकं\nकलौ मलौघभारहारि सर्वतीर्थनायकम् ।\nसुमस्तगुच्छगुच्छद्योतकैसरारुणाधिकं\nत्वदीयपादपङ्कजं नमामि देवि नर्मदे ॥२॥",
                transliteration: "Tvadambu līnadhīnamīnadivyasampraḍāyakaṁ kalau malaughabhārahāri sarvatīrthanāyakam | Sumastagucchagucchadyotakaisarāruṇādhikaṁ tvadīyapādapaṅkajaṁ namāmi devi narmade ||2||",
                meaning: "O Devi Narmada, Your waters grant divine states to the humble fish living within them. In this age of Kali, You are the foremost of all holy rivers, removing the burden of impurities. Your beauty surpasses that of a flower cluster with shining red stamens. I bow to Your lotus feet."
            },
            {
                verse: 3,
                sanskrit: "महागभीरनीरपूरपापधूतभूतलं\nध्वनत्समस्तपातकारिदारितापदाचलम् ।\nजगल्लये महाभये मृकुण्डसूनुहर्म्यदे\nत्वदीयपादपङ्कजं नमामि देवि नर्मदे ॥३॥",
                transliteration: "Mahāgabhīranīrapūrapāpadhūtabhūtalaṁ dhvanatsamastapātakāridāritāpadācalam | Jagallaye mahābhaye mṛkuṇḍasūnuharmyade tvadīyapādapaṅkajaṁ namāmi devi narmade ||3||",
                meaning: "O Devi Narmada, Your deep, flowing waters cleanse the sins of the earth. Your roaring sound shatters the mountains of misery created by all sins. During the great fear of cosmic dissolution, You provided refuge to the son of Mrikundu (Markandeya). I bow to Your lotus feet."
            },
            {
                verse: 4,
                sanskrit: "गतं तदैव मे भयं त्वदम्बु वीक्षितं यदा\nमृकुण्डसूनुशौनकासुरारिसेवितं सदा ।\nपुनर्भवाब्धिजन्मजं भवाब्धिदुःखभर्मदे\nत्वदीयपादपङ्कजं नमामि देवि नर्मदे ॥४॥",
                transliteration: "Gataṁ tadaiva me bhayaṁ tvadambu vīkṣitaṁ yadā mṛkuṇḍasūnuśaunakāsurārisevitaṁ sadā | Punarbhavābdhijanmajaṁ bhavābdhiduḥkhabharmade tvadīyapādapaṅkajaṁ namāmi devi narmade ||4||",
                meaning: "O Devi Narmada, my fear vanished the moment I gazed upon Your waters. You are ever served by Markandeya, Shaunaka, and the enemies of demons. You are the remover of the sorrows born from the ocean of rebirth and worldly existence. I bow to Your lotus feet."
            },
            {
                verse: 5,
                sanskrit: "अलक्ष्यलक्षकिन्नरामरासुरादिपूजितं\nसुलक्ष्यनीरतीरधीरपक्षिलक्षकूजितम् ।\nवसिष्ठशिष्टपिप्पलादिकर्दमादिशर्मदे\nत्वदीयपादपङ्कजं नमामि देवि नर्मदे ॥५॥",
                transliteration: "Alakṣyalakṣakinnarāmarāsurādipūjitaṁ sulakṣyanīratīradhīrapakṣilakṣakūjitam | Vasiṣṭhaśiṣṭapippalādikardamādiśarmade tvadīyapādapaṅkajaṁ namāmi devi narmade ||5||",
                meaning: "O Devi Narmada, You are worshipped by countless unseen Kinnaras, Devas, and Asuras. Your beautiful banks echo with the chirping of millions of wise birds. You have bestowed happiness upon great sages like Vasishtha, Pippalada, and Kardama. I bow to Your lotus feet."
            },
            {
                verse: 6,
                sanskrit: "सनत्कुमारनाचिकेतकश्यपात्रिषट्पदै-\nर्धृतं स्वकीयमानसेषु नारदादिषट्पदैः ।\nरवीन्दुरन्तिदेवदेवराजकर्मशर्मदे\nत्वदीयपादपङ्कजं नमामि देवि नर्मदे ॥६॥",
                transliteration: "Sanatkumāranāciketakāśyapātriṣaṭpadairdhṛtaṁ svakīyamānaseṣu nāradādiṣaṭpadaiḥ | Ravīndurantidevadevarājakarmaśarmade tvadīyapādapaṅkajaṁ namāmi devi narmade ||6||",
                meaning: "O Devi Narmada, You are held in the hearts of Sanatkumara, Nachiketa, Kashyapa, and Atri, who are like bees at Your lotus feet. You have granted bliss through their actions to the Sun, Moon, and Indra. I bow to Your lotus feet."
            },
            {
                verse: 7,
                sanskrit: "अलक्षलक्षलक्षपापलक्षसारसायुधं\nततस्तु जीवजन्तुतन्तुभुक्तिमुक्तिदायकम् ।\nविरिञ्चिविष्णुशङ्करस्वकीयधामवर्मदे\nत्वदीयपादपङ्कजं नमामि देवि नर्मदे ॥७॥",
                transliteration: "Alakṣalakṣalakṣapāpalakṣasārasāyudhaṁ tatastu jīvajantutantubhuktimuktidāyakam | Viriñciviṣṇuśaṅkarasvakīyadhāmavarmade tvadīyapādapaṅkajaṁ namāmi devi narmade ||7||",
                meaning: "O Devi Narmada, You are a weapon against countless sins. You grant worldly enjoyment and liberation to all living beings. You provide a protective abode like that of Brahma, Vishnu, and Shankara. I bow to Your lotus feet."
            },
            {
                verse: 8,
                sanskrit: "अहोऽद्भुतं स्रुतां श्रुतं श्रुतं स्वनं त्विदं त्वयि\nनृणां चति स्फुटं स्फुरत्प्रकृष्टबुद्धिचारु दे ।\nममाऽस्तु देवि भावदात्मजाभिरातिशर्मदे\nत्वदीयपादपङ्कजं नमामि देवि नर्मदे ॥८॥",
                transliteration: "Aho'dbhutaṁ srutāṁ śrutaṁ śrutaṁ svanaṁ tvidaṁ tvayi nṛṇāṁ cati sphuṭaṁ sphuratprakṛṣṭabuddhicāru de | Mamā'stu devi bhāvadātmajābhirātiśarmade tvadīyapādapaṅkajaṁ namāmi devi narmade ||8||",
                meaning: "O Devi Narmada, how wonderful is this sound of your flowing waters! Hearing it grants humans clear and sharp intellect. O Devi, daughter of Bhava (Shiva), granter of supreme bliss, may I always revere Your lotus feet. I bow to Your lotus feet."
            },
            {
                verse: 9,
                sanskrit: "नर्मदाष्टकं इदं तु नित्यमेव यः पठेत्\nसुप्रभाति शुद्धमानसो नरः सदा ।\nस त्वधोगतिं न याति दुर्लभं गतिं लभेत्\nतस्य देवि सर्वदा सुदुर्लभं महेश्वरि ॥९॥",
                transliteration: "Narmadāṣṭakaṁ idaṁ tu nityameva yaḥ paṭhet suprabhāti śuddhamānaso naraḥ sadā | Sa tvadhogatiṁ na yāti durlabhaṁ gatiṁ labhet tasya devi sarvadā sudurlabhaṁ maheśvari ||9||",
                meaning: "Whoever recites this Narmadashtakam every day in the morning with a pure mind, will never face downfall and will attain a rare, exalted state. O Devi, O Mahesvari, for them, nothing will ever be difficult to achieve."
            }
        ],
        description: "Glorifies the sanctity and purifying power of the Narmada.",
        aiHint: "narmada river shiva ashtakam sacred water",
        image: `https://picsum.photos/seed/narmadashtakam/400/225`
    },
    {
        id: "kapalika-stotra",
        title: "Kapalika Stotra",
        sanskritTitle: "कपालिक स्तोत्र",
        deity: "Bhairava (Shiva)",
        composer: "Attributed to Adi Shankaracharya",
        verse_count: "8 verses",
        theme: "Praises the Kapalika form of Bhairava, fierce and ascetic.",
        verses: [
            {
                verse: 1,
                sanskrit: "भजे व्रजैकमण्डनं समस्तपापखण्डनम् ।\nस्वभक्तचित्तरञ्जनं सदैव नन्दनन्दनम् ॥",
                transliteration: "bhaje vrajaikamaṇḍanaṃ samastapāpakhaṇḍanam |\nsvabhaktacittarañjanaṃ sadaiva nandanandanam ||",
                meaning: "I worship the one who is the ornament of Vraja, the destroyer of all sins, who delights the hearts of his devotees, the son of Nanda, forever."
            },
            {
                verse: 2,
                sanskrit: "सुपिच्छगुच्छमस्तकं सुनादवेणुहस्तकम् ।\nअनङ्गरङ्गसागरं नमामि कृष्णनागरम् ॥",
                transliteration: "supicchagucchamastakaṃ sunādaveṇuhastakam |\nanaṅgaraṅgasāgaraṃ namāmi kṛṣṇanāgaram ||",
                meaning: "I bow to Krishna, the charming one, whose head is adorned with a beautiful peacock feather, who holds a melodious flute in his hand, and who is an ocean of the art of love."
            },
            {
                verse: 3,
                sanskrit: "मनोजगर्वमोचनं विशाललोललोचनम् ।\nविधूतगोपशोचनं नमामि पद्मलोचनम् ॥",
                transliteration: "manojagarvamocanaṃ viśālalolalocanam |\nvidhūtagopaśocanaṃ namāmi padmalocanam ||",
                meaning: "I bow to the lotus-eyed one, who destroys the pride of the mind, whose large eyes are ever-moving, and who dispels the sorrows of the cowherds."
            },
            {
                verse: 4,
                sanskrit: "करारविन्दभूधरं स्मितावलोकसुन्दरम् ।\nमहेन्द्रमानदारणं नमामि कृष्णवारणम् ॥",
                transliteration: "karāravindabhūdharaṃ smitāvalokasundaram |\nmahendramānadāraṇaṃ namāmi kṛṣṇavāraṇam ||",
                meaning: "I bow to Krishna, the elephant, who lifts the mountain with his lotus-like hand, whose smiling glance is beautiful, and who shatters the pride of Indra."
            },
            {
                verse: 5,
                sanskrit: "कदम्बसूनकुण्डलं सुचारुगण्डमण्डलम् ।\nव्रजाङ्गनैकवल्लभं नमामि कृष्णदुर्लभम् ॥",
                transliteration: "kadambasūnakuṇḍalaṃ sucārugaṇḍamaṇḍalam |\nvrajāṅganaikavallabhaṃ namāmi kṛṣṇadurlabham ||",
                meaning: "I bow to the rare Krishna, whose earrings are made of Kadamba flowers, whose cheeks are beautifully round, and who is the sole beloved of the women of Vraja."
            },
            {
                verse: 6,
                sanskrit: "यशोदया समोदया सगोपया सनन्दया ।\nयुतं सुखैकदायकं नमामि गोपनायकम् ॥",
                transliteration: "yaśodayā samodayā sagopayā sanandayā |\nyutaṃ sukhaikadāyakaṃ namāmi gopanāyakam ||",
                meaning: "I bow to the leader of the cowherds, who, accompanied by Yashoda, the cowherds, and Nanda, is the sole bestower of happiness."
            },
            {
                verse: 7,
                sanskrit: "सदैव पादपङ्कजं मदीयमानसे निजम् ।\nदधानमुत्तमालकं नमामि नन्दबालकम् ॥",
                transliteration: "sadaiva pādapaṅkajaṃ madīyamānase nijam |\ndadhānamuttamālakaṃ namāmi nandabālakam ||",
                meaning: "I bow to the child of Nanda, who always places his own lotus-like feet in my mind, and who has the most beautiful locks of hair."
            },
            {
                verse: 8,
                sanskrit: "समस्तदोषशोषणं समस्तलोकपोषणम् ।\nसमस्तगोपमानसं नमामि नन्दलालसम् ॥",
                transliteration: "samastadoṣaśoṣaṇaṃ samastalokapoṣaṇam |\nsamastagopamānasaṃ namāmi nandalālasam ||",
                meaning: "I bow to the one who is desired by Nanda, who dries up all faults, nourishes all worlds, and is the mind of all the cowherds."
            }
        ],
        description: "Praises the Kapalika form of Bhairava, fierce and ascetic.",
        aiHint: "bhairava shiva kapalika fierce ascetic tantra",
        image: `https://picsum.photos/seed/kapalika-stotra/400/225`
    },
    {
        id: "ardhanarishvara-stotram",
        title: "Ardhanarishvara Stotram",
        sanskritTitle: "अर्धनारीश्वर स्तोत्रम्",
        deity: "Shiva & Parvati as Ardhanarishvara",
        composer: "Adi Shankaracharya",
        verse_count: "Multiple verses",
        theme: "Praises the union of Shiva and Parvati as one form.",
        verses: [
            {
                verse: 1,
                sanskrit: "चाम्पेयगौरार्धशरीरकायै कर्पूरगौरार्धशरीरकाय ।\nधम्मिल्लकायै च जटाधराय नमः शिवायै च नमः शिवाय ॥१॥",
                meaning: "Salutations to Shivai (Parvati) and Salutations to Shiva. To Her whose half-body is golden like a Champaka flower, and to Him whose half-body is white like camphor. To Her with beautifully braided hair, and to Him with matted locks.",
                transliteration: "cāmpeyagaurārdhaśarīrakāyai karpūragaurārdhaśarīrakāya |\ndhammillakāyai ca jaṭādharāya namaḥ śivāyai ca namaḥ śivāya ||1||"
            },
            {
                verse: 2,
                sanskrit: "कस्तूरिकाकुङ्कुमचर्चितायै चितारजःपुञ्जविचर्चिताय ।\nकृतस्मरायै विकृतस्मराय नमः शिवायै च नमः शिवाय ॥२॥",
                meaning: "Salutations to Shivai and Salutations to Shiva. To Her who is smeared with musk and saffron, and to Him who is smeared with the ashes of the funeral pyre. To Her who revived Kama (the God of Love), and to Him who destroyed Kama.",
                transliteration: "kastūrikākuṅkumacarcitāyai citārajaḥpuñjavicarcitāya |\nkṛtasmarāyai vikṛtasmarāya namaḥ śivāyai ca namaḥ śivāya ||2||"
            },
            {
                verse: 3,
                sanskrit: "चलत्क्वणत्कङ्कणनूपुरायै पादाब्जराजत्फणिभूषणाय ।\nजगज्जितायै त्रिपुरान्तकाय नमः शिवायै च नमः शिवाय ॥३॥",
                meaning: "Salutations to Shivai and Salutations to Shiva. To Her with tinkling bracelets and anklets, and to Him whose lotus feet are adorned with shining serpent-ornaments. To Her who conquered the world, and to Him who is the destroyer of the three cities (Tripura).",
                transliteration: "calatkvaṇatkaṅkaṇanūpurāyai pādābjarājatphaṇibhūṣaṇāya |\njagajjitāyai tripurāntakāya namaḥ śivāyai ca namaḥ śivāya ||3||"
            },
            {
                verse: 4,
                sanskrit: "विशालनीलोत्पललोचनायै विकासिपङ्केरुहलोचनाय ।\nसमेक्षणायै विषमेक्षणाय नमः शिवायै च नमः शिवाय ॥४॥",
                meaning: "Salutations to Shivai and Salutations to Shiva. To Her whose eyes are like large blue lotuses, and to Him whose eyes are like full-blown lotuses. To Her with an even number of eyes (two), and to Him with an odd number of eyes (three).",
                transliteration: "viśālanīlotpalalocanāyai vikāsipaṅkeruhalocanāya |\nsamekṣaṇāyai viṣamekṣaṇāya namaḥ śivāyai ca namaḥ śivāya ||4||"
            },
            {
                verse: 5,
                sanskrit: "मन्दारमालाकुलितालकायै कपालमालाङ्कितकन्धराय ।\nदिव्याम्बरायै च दिगम्बराय नमः शिवायै च नमः शिवाय ॥५॥",
                meaning: "Salutations to Shivai and Salutations to Shiva. To Her whose hair is adorned with garlands of Mandara flowers, and to Him whose neck is marked with a garland of skulls. To Her who wears divine garments, and to Him who is clad in the directions (naked).",
                transliteration: "mandāramālākulitālakāyai kapālamālāṅkitakandharāya |\ndivyāmbarāyai ca digambarāya namaḥ śivāyai ca namaḥ śivāya ||5||"
            },
            {
                verse: 6,
                sanskrit: "अम्भोधरश्यामलकुन्तलायै तडित्प्रभाताम्रजटाधराय ।\nनिरीश्वरायै निखिलेश्वराय नमः शिवायै च नमः शिवाय ॥६॥",
                meaning: "Salutations to Shivai and Salutations to Shiva. To Her whose hair is dark like rain clouds, and to Him whose matted locks are coppery like the glow of lightning. To Her who is without a lord, and to Him who is the Lord of All.",
                transliteration: "ambhodharaśyāmalakuntalāyai taḍitprabhātāmrajaṭādharāya |\nnirīśvarāyai nikhileśvarāya namaḥ śivāyai ca namaḥ śivāya ||6||"
            },
            {
                verse: 7,
                sanskrit: "प्रपञ्चसृष्ट्युन्मुखलास्यकायै समस्तसंहारकताण्डवाय ।\nजगज्जनन्यै जगदेकपित्रे नमः शिवायै च नमः शिवाय ॥७॥",
                meaning: "Salutations to Shivai and Salutations to Shiva. To Her whose graceful dance (Lasya) is inclined towards the creation of the universe, and to Him whose fierce dance (Tandava) brings about the destruction of everything. To Her who is the mother of the world, and to Him who is the sole father of the world.",
                transliteration: "prapañcasṛṣṭyunmukhalāsyakāyai samastasaṃhārakatāṇḍavāya |\njagajjananyai jagadekapitre namaḥ śivāyai ca namaḥ śivāya ||7||"
            },
            {
                verse: 8,
                sanskrit: "प्रदीप्तरत्नोज्ज्वलकुण्डलायै स्फुरन्महापन्नगभूषणाय ।\nशिवान्वितायै च शिवान्विताय नमः शिवायै च नमः शिवाय ॥८॥",
                meaning: "Salutations to Shivai and Salutations to Shiva. To Her whose earrings shine brightly with blazing gems, and to Him who is adorned with a great glittering serpent. To Her who is united with Shiva, and to Him who is united with Shivai (Shakti).",
                transliteration: "pradīptaratnojjvalakuṇḍalāyai sphuranmahāpannagabhūṣaṇāya |\nśivānvitāyai ca śivānvitāya namaḥ śivāyai ca namaḥ śivāya ||8||"
            },
            {
                verse: 9,
                sanskrit: "एतत् पठेदष्टकमिष्टदं यो भक्त्या स मान्यो भुवि दीर्घजीवी ।\nप्राप्नोति सौभाग्यमनन्तकालं भूयात् सदा तस्य समस्तसिद्धिः ॥९॥",
                meaning: "He who recites this octet, which bestows wishes, with devotion, will be honored in the world and live a long life. He will attain endless good fortune, and all accomplishments will always be his.",
                transliteration: "etat paṭhedaṣṭakamiṣṭadaṃ yo bhaktyā sa mānyo bhuvi dīrghajīvī |\nprāpnoti saubhāgyamanantakālaṃ bhūyāt sadā tasya samastasiddhiḥ ||9||"
            }
        ],
        description: "Praises the union of Shiva and Parvati as one form.",
        aiHint: "ardhanarishvara shiva parvati union half male female",
        image: `https://picsum.photos/seed/ardhanarishvara-stotram/400/225`
    },
    {
        id: "mrityunjaya-kavacham",
        title: "Mrityunjaya Kavacham",
        sanskritTitle: "मृत्युंजय कवचम्",
        deity: "Shiva (Mrityunjaya)",
        composer: "Puranic source (Markandeya Purana)",
        verse_count: "Multiple verses",
        theme: "Protective hymn invoking Shiva’s power over death.",
        verses: [
             {
                verse: 0.1,
                sanskrit: "ॐ अस्य श्रीमहामृत्युञ्जयकवचस्य श्रीभैरव ऋषिः, गायत्री छन्दः, श्रीमहामृत्युञ्जयो देवता, ॐ बीजं, जूं शक्तिः, सः कीलकं, हौं तत्त्वं, चतुर्वर्गसाधने विनियोगः ॥",
                meaning: "Om. Of this great Mrityunjaya armor (kavacha), the sage is Bhairava, the meter is Gayatri, the deity is Mahamrityunjaya. Om is the seed (bija), Juṁ is the power (shakti), Saḥ is the pin (kilaka), Hauṁ is the principle (tattva). It is employed for achieving the four goals of human life (Dharma, Artha, Kama, Moksha).",
                transliteration: "om asya śrīmahāmṛtyuñjayakavacasya śrībhairava ṛṣiḥ, gāyatrī chandaḥ, śrīmahāmṛtyuñjayo devatā, oṃ bījaṃ, jūṃ śaktiḥ, saḥ kīlakaṃ, hauṃ tattvaṃ, caturvargasādhane viniyogaḥ ||"
            },
            {
                verse: 1,
                sanskrit: "ध्यायेन्नित्यं महेशं रजतगिरिनिभं चारुचन्द्रावतंसं\nरत्नाकल्पोज्ज्वलाङ्गं परशुमृगवराभीतिहस्तं प्रसन्नम् ।\nपद्मासीनं समन्तात् स्तुतममरगणैर्व्याघ्रकृत्तिं वसानं\nविश्वाद्यं विश्ववन्द्यं निखिलभयहरं पञ्चवक्त्रं त्रिनेत्रम् ॥",
                meaning: "One should always meditate on Mahesh, who is like a silver mountain, beautifully adorned with the crescent moon; whose body shines with jeweled ornaments, holding a battle-axe, a deer, and showing gestures of granting boons and fearlessness; seated on a lotus, praised all around by hosts of gods, wearing a tiger skin; the origin of the universe, worshipped by the universe, the remover of all fears, with five faces and three eyes.",
                transliteration: "dhyāyennityaṃ maheśaṃ rajatagirinibhaṃ cārucandrāvataṃsaṃ ratnākalpojjvalāṅgaṃ paraśumṛgavarābhītihastaṃ prasannam |\npadmāsīnaṃ samantāt stutamamargaṇairvyāghrakṛttiṃ vasānaṃ viśvādyaṃ viśvavandyaṃ nikhilabhayaharaṃ pañcavaktraṃ trinetram ||"
            },
            {
                verse: 2,
                sanskrit: "शिरो मे महादेवः पातु, भालं पिनाकी ।\nनेत्रे मे त्रिनयनः पातु, कर्णौ पातु महेश्वरः ॥",
                meaning: "May Mahadeva protect my head, Pinaki protect my forehead. May the Three-Eyed One protect my eyes, may Maheshvara protect my ears.",
                transliteration: "śiro me mahādevaḥ pātu, bhālaṃ pinākī |\nnetre me trinayanaḥ pātu, karṇau pātu maheśvaraḥ ||"
            },
            {
                verse: 3,
                sanskrit: "नासिकाम् मे महादेवो, मुखं पातु महेश्वरः ।\nजिह्वां मे वाक्पतिः पातु, दन्तान् मे प्रमथाधिपः ॥",
                meaning: "May Mahadeva protect my nose, may Maheshvara protect my face. May the Lord of Speech protect my tongue, may the Lord of Pramathas protect my teeth.",
                transliteration: "nāsikām me mahādevo, mukhaṃ pātu maheśvaraḥ |\njihvāṃ me vākpatiḥ pātu, dantān me pramathādhipaḥ ||"
            },
            {
                verse: 4,
                sanskrit: "ओष्ठौ पातु उमाकान्तः, कण्ठं मे नीलकण्ठकः ।\nग्रीवां पातु पशुपतिः, स्कन्धौ मे शङ्करस्तथा ॥",
                meaning: "May Uma's husband protect my lips, may the Blue-Throated One protect my throat. May Pashupati protect my neck, and Shankara protect my shoulders.",
                transliteration: "oṣṭhau pātu umākāntaḥ, kaṇṭhaṃ me nīlakaṇṭhakaḥ |\ngrīvāṃ pātu paśupatiḥ, skandhau me śaṅkarastathā ||"
            }
        ],
        description: "Protective hymn invoking Shiva’s power over death.",
        aiHint: "shiva mrityunjaya kavacham protection death conqueror",
        image: `https://picsum.photos/seed/mrityunjaya-kavacham/400/225`
    }
];

// Function to get all stotras
export const getAllStotras = (): Stotra[] => {
  return [...stotrasData].sort((a, b) => a.title.localeCompare(b.title));
};

// Function to get a specific stotra by ID
export const getStotraById = (id: string): Stotra | undefined => {
  return stotrasData.find(stotra => stotra.id === id);
};


